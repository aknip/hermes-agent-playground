# Hermes Kanban — Tutorial für Hermes Agent 0.20.0 auf macOS

Dieses Verzeichnis ist eine überarbeitete, vollständig nachgespielte Fassung des
offiziellen Tutorials
[Kanban tutorial](https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban-tutorial).

Das Original beschreibt vier Stories, setzt aber stillschweigend voraus, dass
acht Spezialisten-Profile bereits existieren, und lässt offen, was ins Terminal
gehört und was in die grafische Oberfläche. Diese Fassung schließt beide Lücken
und ist auf einer Standard-Installation von Hermes Agent v0.20.0 (2026.8.3)
unter macOS **komplett durchgespielt** worden.

## Inhalt

| Datei / Verzeichnis | Zweck |
|---|---|
| **[TUTORIAL.md](TUTORIAL.md)** | Das Tutorial. Hier anfangen. |
| **[VERIFIKATION.md](VERIFIKATION.md)** | Was ich real ausgeführt habe, mit echten Ausgaben — und was ich *nicht* verifizieren konnte. |
| `Story 0 - Setup/` | `setup.sh`, `teardown.sh`, `pump.sh`, `reset-workspaces.sh` — Board und die acht Profile |
| `Story 1 - Solo Dev/` | Abhängigkeitskette und strukturierter Handoff |
| `Story 2 - Fleet Farming/` | Zwölf unabhängige Tasks auf drei Spezialisten |
| `Story 3 - Role Pipeline/` | PM → Engineer → Reviewer, mit Block und Retry |
| `Story 4 - Circuit Breaker/` | Circuit Breaker, Respawn-Sperre, Crash Recovery |

Jedes Story-Verzeichnis ist gleich aufgebaut:

```
Story N - …/
├── create-tasks.sh   (bzw. breaker.sh / crash.sh)  legt die Tasks an
├── seed/             unveränderliche Startdateien — der Master
└── workspace/        Arbeitskopie; hier arbeiten die Worker wirklich
```

`workspace/` wird aus `seed/` aufgebaut und lässt sich jederzeit zurücksetzen
(`Story 0 - Setup/reset-workspaces.sh`). Das ist nötig, weil Worker auch
Startdateien **überschreiben** — sonst wäre das Tutorial nur einmal
durchführbar. Alle Datei-Inhalte stehen zusätzlich im Tutorialtext, damit du
nichts blind ausführen musst.

Die Skripte schreiben ihre Task-IDs in `task-ids.env` neben sich; mit
`source task-ids.env` hast du sie in den Folgeschritten zur Hand.

## Aktueller Zustand deiner Installation

Weil ich das Tutorial auf deinem Rechner durchgespielt habe, ist Story 0 bei
dir **schon erledigt**. Stand bei Abgabe:

- Board `kanban-tutorial` existiert und ist leer — auch keine archivierten
  Reste (Board neu aufgebaut, nicht bloß aufgeräumt).
- Die acht Profile existieren, alle mit `ON DISK = yes`.
- Alle `workspace/`-Verzeichnisse sind deckungsgleich mit ihrem `seed/`.
- Dein `default`-Board, deine Profile `developer` / `summarizer` / `test-me` und
  deine Root-Konfiguration sind unverändert.

**Prüf das kurz nach, bevor du anfängst** — bei dir läuft ein Gateway, und das
startet Aufgaben von selbst (siehe Story 0, Schritt 0.4):

```bash
hermes kanban --board kanban-tutorial list --archived   # erwartet: (no matching tasks)
hermes kanban --board kanban-tutorial assignees         # erwartet: 8× ON DISK = yes
cd "Story 0 - Setup" && ./reset-workspaces.sh --diff    # erwartet: keine Ausgabe je Story
```

Weicht etwas ab, stellst du den Ausgangszustand so wieder her:

```bash
cd "Story 0 - Setup"
./reset-workspaces.sh          # nur Dateien
./teardown.sh -y && ./setup.sh # alles von Null
```

## Voraussetzungen

```bash
hermes --version     # erwartet: Hermes Agent v0.20.0 oder neuer
jq --version         # falls nicht vorhanden: brew install jq
hermes config get model.default    # muss ein Modell zeigen, nicht leer sein
```

Mehr braucht es nicht. Board, Profile und Arbeitsdateien legt das Tutorial
selbst an. Deine bestehenden Profile, dein `default`-Board und deine
Root-Konfiguration werden nicht angefasst.

## Die drei Oberflächen — was geht wo?

Das ist die Frage, die das Original-Tutorial nicht beantwortet. Es gibt **drei**
Zugänge zum selben Board, und sie sind nicht gleichwertig.

### 1. Terminal (`hermes kanban …`)

Vollständig. Jede Operation ist hier verfügbar, und nur hier gibt es die
Diagnose-Befehle, die im Tutorial die eigentliche Lehre tragen.

### 2. Web-Dashboard (`hermes dashboard` → <http://127.0.0.1:9119>)

**Das ist die Oberfläche, die das Original-Tutorial zeigt.** Alle Screenshots
und alle UI-Elemente, die dort beschrieben werden — „Nudge dispatcher", die
Pille „Orchestration: Auto/Manual", „⚗ Decompose", „✨ Specify",
„Lanes by profile" — gehören zu dieser Web-Oberfläche.

### 3. Desktop-App (`/Applications/Hermes.app`)

Die Desktop-App hat ein **eigenes, neueres** Kanban-Board — sie bettet nicht
das Web-Dashboard ein. Zwei Dinge dazu, die man wissen muss:

- **Das Kanban-Board ist in der Desktop-App standardmäßig ausgeschaltet.**
  Erst einschalten unter **Settings ▸ Plugins ▸ Kanban**. Danach erscheint
  „Kanban" in der linken Seitenleiste.
- Es fehlen zwei Knöpfe aus dem Tutorial: es gibt **keinen** expliziten
  „Nudge dispatcher"-Button (ein Dispatch-Anstoß läuft in der Desktop-App
  automatisch bei jeder Schreiboperation mit) und **kein** „✨ Specify" pro
  Karte. „Decompose" gibt es nur als Auto-Schalter in den
  Orchestrierungs-Einstellungen, nicht pro Karte.

### Matrix

| Funktion | Terminal | Web-Dashboard | Desktop-App |
|---|---|---|---|
| Task anlegen | `kanban create` | „New task"-Dialog | „New task"-Dialog |
| Board ansehen | `kanban list` | Spaltenansicht | Spaltenansicht |
| Status ändern | `kanban promote/block/unblock/archive` | Drag & Drop | Drag & Drop |
| Task-Details | `kanban show` | Drawer rechts | Drawer rechts |
| **Attempt-Historie (Runs)** | `kanban runs` | Drawer ▸ Run History | Drawer ▸ Runs |
| **Worker-Kontext ansehen** | `kanban context` | — | — |
| **Worker-Log live** | `kanban log --tail N` | Drawer ▸ Worker log | Drawer ▸ Worker log |
| **Event-Stream live** | `kanban watch` / `tail` | Drawer ▸ Activity | Drawer ▸ Activity |
| Dispatcher anstoßen | `kanban dispatch` | „Nudge dispatcher" | automatisch bei Schreibzugriff |
| Auto-Decompose an/aus | `config set kanban.auto_decompose` | „Orchestration"-Pille | Orchestrierungs-Einstellungen |
| Einzelnen Task decomposen | `kanban decompose <id>` | „⚗ Decompose" auf der Karte | — |
| Triage-Task ausformulieren | `kanban specify <id>` | „✨ Specify" auf der Karte | — |
| Board wechseln / anlegen | `kanban boards …` | Board-Auswahl | Board-Auswahl in der Titelleiste |
| Profil-Beschreibungen pflegen | `hermes profile describe` | — | Orchestrierungs-Einstellungen |
| Statistik | `kanban stats` | Zählwerte je Spalte | Zählwerte je Spalte |

**Praktische Empfehlung für dieses Tutorial:** Terminal für die Befehle, und
daneben das **Web-Dashboard** offen, weil es der Vorlage entspricht. Die
Desktop-App ist für den Alltag angenehmer, zeigt aber nicht dieselben Knöpfe.

## Reihenfolge

```
Story 0 - Setup      →  einmal, Pflicht
Story 1 - Solo Dev   →  Abhängigkeiten und Handoff verstehen
Story 2 - Fleet      →  Parallelität
Story 3 - Pipeline   →  Block, Retry, Attempt-Historie
Story 4 - Breaker    →  Fehlerfälle
```

Stories 1–4 sind nach dem Setup unabhängig voneinander, laufen aber alle auf
demselben Board. Wenn du sie einzeln fahren willst, benutze die
Tenant-Filter (`--tenant auth-project`, `content-ops`, `reset-feature`, `ops`).

## Abweichungen von der offiziellen Doku

Alle bewusst und jeweils im Tutorial an der betreffenden Stelle begründet:

1. **Eigenes Board `kanban-tutorial`** statt `default`. Dein `default`-Board hat
   in der Regel schon echte Aufgaben; ein Sandbox-Board lässt sich am Ende
   restlos löschen.
2. **Die acht Profile werden angelegt** — das Original setzt sie voraus. Dabei
   ist `hermes profile create` **allein nicht ausreichend**: ohne `config.yaml`
   erkennt der Kanban-Dispatcher das Profil nicht als Assignee. Siehe Story 0.
3. **Echte Arbeitsverzeichnisse** (`--workspace dir:…`) statt `scratch`, damit
   du siehst, was die Worker produziert haben.
4. **Story 4a** benutzt einen anderen Auslöser für den Circuit Breaker als die
   Doku. Der dort genannte (fehlendes `AWS_ACCESS_KEY_ID`) erzeugt in 0.20.0
   keinen Spawn-Fehler. Begründung und Ersatz in Story 4.
5. **Story 4b** benutzt `kill -9` statt eines OOM-Kills — derselbe
   Erkennungspfad im Dispatcher, aber reproduzierbar.
6. **Das Board hat 8 Spalten, nicht 6.** Die Doku listet Triage, Todo, Ready,
   In progress, Blocked, Done. Tatsächlich kennt 0.20.0 zusätzlich
   **Scheduled** und **Review**.

Zwei Mechanismen, die in **keiner** Doku stehen und die du kennen solltest,
weil sie Tasks stillschweigend anhalten bzw. starten — beide real ausgelöst und
in Story 4 bzw. Story 0 beschrieben:

7. **Respawn-Sperre.** Sieht ein Fehlertext nach Auth oder Quota aus
   („permission denied", „429", „quota", „invalid api key" …), versucht der
   Dispatcher es **gar nicht** erneut. Der Task bleibt auf `ready` und sieht
   aus wie „wartet" — und `hermes kanban diagnostics` meldet ihn nicht.
8. **Ein laufendes Gateway greift auf jedes Board zu**, auch auf ein gerade neu
   erstelltes. Du kannst einen Task also nicht „erst anlegen und später
   ansehen", solange es läuft.

## Rückbau

```bash
cd "Story 0 - Setup"
./teardown.sh                    # Board + Profile + Arbeitsdateien
./teardown.sh --keep-profiles    # Board + Arbeitsdateien
./teardown.sh --files-only       # nur Arbeitsdateien (zwischen zwei Stories)
```

⚠ Zwischen zwei Stories **`--files-only`** benutzen — sonst löscht das Skript
das Board, auf dem die noch folgenden Stories laufen.

Entfernt Board, Profile, Wrapper-Skripte in `~/.local/bin` und setzt alle
Arbeitsverzeichnisse zurück. Der manuelle Weg Schritt für Schritt steht im
Kapitel „Rückbau" in [TUTORIAL.md](TUTORIAL.md).
