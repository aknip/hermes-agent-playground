# Die acht Tutorial-Profile — Quellinhalte

`setup.sh` legt diese Profile an. Hier stehen die vollständigen Inhalte, falls
du sie von Hand erzeugen, prüfen oder in ein anderes System übertragen willst.

## Was Hermes je Profil auf die Platte legt

`hermes profile create <name> --no-skills --description "…"` erzeugt:

```
~/.hermes/profiles/<name>/
├── .env                    leer, nur Kommentare — API-Keys kämen hierher
├── .no-bundled-skills      Marker: keine Skills mitkopiert
├── profile.yaml            enthält die --description
├── SOUL.md                 Standard-Systemprompt
├── cron/  home/  logs/  memories/  plans/  sessions/  skills/  skins/  workspace/
└── (KEINE config.yaml — die muss separat erzeugt werden!)
```

## Die entscheidende Datei: `config.yaml`

Ohne sie erkennt der Kanban-Dispatcher das Profil nicht als Assignee
(`hermes kanban assignees` zeigt es nicht, Tasks bleiben stumm auf `ready`).

Erzeugen — bevorzugt über die CLI, damit die Werte aus deiner
Root-Installation kommen:

```bash
for key in model.default model.provider model.base_url model.api_mode; do
  hermes -p backend-dev config set "$key" "$(hermes config get "$key")"
done
```

Das Ergebnis sieht bei einer OpenRouter-Installation so aus
(`~/.hermes/profiles/backend-dev/config.yaml`):

```yaml
model:
  default: deepseek/deepseek-v4-flash-0731
  provider: openrouter
  base_url: https://openrouter.ai/api/v1
  api_mode: chat_completions
```

Mehr braucht es nicht: `load_config()` startet bei den eingebauten Defaults und
merged die Profildatei darüber. Alles, was hier nicht steht, wird geerbt.

Ein **API-Key im Profil ist nicht nötig** — die Worker erben die Schlüssel aus
der Umgebung. Verifiziert: ein Worker mit leerer Profil-`.env` lief durch.

## `profile.yaml` — die Beschreibung

```yaml
description: Backend engineer. Designs database schemas, writes migrations, implements
  REST/HTTP API endpoints in Python and TypeScript, and handles auth, sessions and
  tokens.
description_auto: false
```

`description_auto: false` heißt „von Hand geschrieben". `hermes profile describe
--all --auto` überschreibt nur Beschreibungen, die fehlen oder `true` sind.

## Alle acht Beschreibungen

| Profil | Beschreibung |
|---|---|
| `backend-dev` | Backend engineer. Designs database schemas, writes migrations, implements REST/HTTP API endpoints in Python and TypeScript, and handles auth, sessions and tokens. |
| `qa-dev` | QA engineer. Writes integration and end-to-end tests, designs test matrices covering happy path and edge cases, and verifies API contracts. |
| `translator` | Translator. Translates marketing and product copy between English, German, Spanish and French while preserving tone and terminology. |
| `transcriber` | Transcriber. Turns audio and call notes into clean, structured written transcripts with speaker labels and timestamps. |
| `copywriter` | Copywriter. Writes short product descriptions, marketing headlines and e-commerce copy from product attribute data. |
| `pm` | Product manager. Turns rough feature ideas into concrete specs with goal, scope, user-visible behaviour and testable acceptance criteria. |
| `reviewer` | Code reviewer. Reviews diffs and pull requests for correctness, security and missing tests, and either approves or lists concrete required changes. |
| `deploy-bot` | Deployment bot. Runs deployments to staging and production using cloud CLIs and requires cloud credentials in its environment. |

Nachträglich ändern:

```bash
hermes profile describe reviewer --text "Code reviewer. Reviews diffs …"
hermes profile describe reviewer            # aktuelle Beschreibung anzeigen
hermes profile describe --all --auto        # fehlende automatisch generieren
```

Im **Desktop-Board** stehen diese Beschreibungen unter
Orchestrierungs-Einstellungen ▸ *Profile descriptions* und lassen sich dort
bearbeiten oder automatisch generieren.

## Was `hermes profile create` noch anlegt

Ein **Wrapper-Skript** unter `~/.local/bin/<name>`. Damit kannst du ein Profil
direkt ansprechen:

```bash
backend-dev chat            # Chat als backend-dev
backend-dev doctor          # Profil-Diagnose (nützlich bei spawn_failed)
```

Mit `--no-alias` unterdrücken. `teardown.sh` entfernt diese Wrapper wieder.

## SOUL.md

Alle acht Profile bekommen denselben Standard-Systemprompt. Wer einem Profil
eine echte Rolle geben will, editiert `~/.hermes/profiles/<name>/SOUL.md`.
Für dieses Tutorial ist das nicht nötig: der Auftrag steht im Task-Body, und
die Rollen-Beschreibung steht in `profile.yaml`.

Standardinhalt:

```
You are Hermes Agent, an intelligent AI assistant created by Nous Research.
You are helpful, knowledgeable, and direct. You assist users with a wide range
of tasks including answering questions, writing and editing code, analyzing
information, creative work, and executing actions via your tools. You
communicate clearly, admit uncertainty when appropriate, and prioritize being
genuinely useful over being verbose unless otherwise directed below. Be
targeted and efficient in your exploration and investigations.
```
