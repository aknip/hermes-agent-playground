#!/usr/bin/env bash
#
# pump.sh — Dispatcher-Pumpe für das Tutorial
# ===========================================
#
# Stößt wiederholt `hermes kanban dispatch` an und zeigt nach jedem Tick den
# Board-Zustand, bis nichts mehr offen ist (kein ready/running/todo mehr).
#
# Warum es das braucht:
#   Im Normalbetrieb übernimmt das der Dispatcher im Gateway — alle 60 s
#   (kanban.dispatch_interval_seconds). Für ein Tutorial ist das lang, und
#   `hermes gateway start` würde ALLE Boards bedienen. Diese Pumpe arbeitet
#   nur auf dem Tutorial-Board und lässt sich mit Ctrl-C jederzeit stoppen.
#
# Aufruf:
#   ./pump.sh                 # Standard: alle 15 s ein Tick, max. 40 Ticks
#   ./pump.sh 10 100          # alle 10 s, max. 100 Ticks
#   ./pump.sh --once          # genau ein Tick (entspricht "Nudge dispatcher")
#
set -euo pipefail

BOARD="kanban-tutorial"

if [ "${1:-}" = "--once" ]; then
    hermes kanban --board "$BOARD" dispatch
    exit 0
fi

INTERVAL="${1:-15}"
MAX_TICKS="${2:-40}"

command -v jq >/dev/null || { echo "FEHLER: 'jq' fehlt (brew install jq)"; exit 1; }

board_json() { hermes kanban --board "$BOARD" list --json 2>/dev/null || echo '[]'; }

for tick in $(seq 1 "$MAX_TICKS"); do
    hermes kanban --board "$BOARD" dispatch >/dev/null 2>&1 || true

    json="$(board_json)"
    open=$(printf '%s' "$json" | jq '[.[] | select(.status=="ready" or .status=="running" or .status=="todo")] | length')
    summary=$(printf '%s' "$json" | jq -r 'group_by(.status) | map("\(.[0].status)=\(length)") | join("  ")')

    printf '[%02d] %s\n' "$tick" "${summary:-leer}"

    if [ "$open" -eq 0 ]; then
        echo
        echo "Nichts mehr offen — Pumpe beendet."
        hermes kanban --board "$BOARD" list
        exit 0
    fi
    sleep "$INTERVAL"
done

echo
echo "Maximale Tick-Zahl ($MAX_TICKS) erreicht, es ist noch Arbeit offen:"
hermes kanban --board "$BOARD" list
