#!/usr/bin/env bash
#
# reset-workspaces.sh — Arbeitsverzeichnisse auf den Ausgangszustand zurücksetzen
# ==============================================================================
#
# Jede Story hat zwei Verzeichnisse:
#
#   seed/        unveränderliche Startdateien (Master, wird nie beschrieben)
#   workspace/   Arbeitskopie — hier arbeiten die Worker
#
# Dieses Skript ersetzt workspace/ vollständig durch eine frische Kopie von
# seed/. Damit ist jede Story beliebig oft wiederholbar, auch wenn ein Worker
# eine Startdatei überschrieben hat (in Story 1 passiert genau das mit
# auth/__init__.py, in Story 3 mit REVIEW-FEEDBACK.md und auth/reset.py).
#
# Aufruf:
#   ./reset-workspaces.sh                 # alle Stories
#   ./reset-workspaces.sh "Story 1 - Solo Dev"   # nur eine
#   ./reset-workspaces.sh --diff          # nur zeigen, was sich unterscheidet
#
set -euo pipefail

TUTORIAL_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIFF_ONLY=0
TARGETS=()

for arg in "$@"; do
    case "$arg" in
        --diff) DIFF_ONLY=1 ;;
        *) TARGETS+=("$arg") ;;
    esac
done

if [ "${#TARGETS[@]}" -eq 0 ]; then
    shopt -s nullglob
    for d in "$TUTORIAL_ROOT"/Story\ *; do
        [ -d "$d/seed" ] && TARGETS+=("$(basename "$d")")
    done
    shopt -u nullglob
fi

for name in "${TARGETS[@]}"; do
    story="$TUTORIAL_ROOT/$name"
    seed="$story/seed"
    ws="$story/workspace"

    if [ ! -d "$seed" ]; then
        echo "übersprungen: $name (kein seed/)"
        continue
    fi

    if [ "$DIFF_ONLY" -eq 1 ]; then
        echo "=== $name ==="
        if [ -d "$ws" ]; then
            # -q: nur melden, dass etwas abweicht. Alles, was hier auftaucht,
            # hat ein Worker erzeugt oder verändert.
            diff -rq "$seed" "$ws" 2>&1 | sed 's/^/  /' || true
        else
            echo "  workspace/ existiert nicht"
        fi
        continue
    fi

    rm -rf "$ws"
    mkdir -p "$ws"
    cp -R "$seed"/. "$ws"/
    count=$(find "$ws" -type f | wc -l | tr -d ' ')
    printf '%-30s zurückgesetzt (%s Startdateien)\n' "$name" "$count"
done
