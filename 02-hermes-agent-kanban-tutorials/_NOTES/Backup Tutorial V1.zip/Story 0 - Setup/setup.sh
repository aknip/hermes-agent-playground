#!/usr/bin/env bash
#
# Story 0 — Setup für das Hermes Kanban Tutorial
# ==============================================
#
# Legt alles an, was die Stories 1–4 brauchen:
#   1. ein eigenes Kanban-Board "kanban-tutorial" (dein default-Board bleibt unberührt)
#   2. acht Tutorial-Profile (backend-dev, qa-dev, translator, transcriber,
#      copywriter, pm, reviewer, deploy-bot)
#   3. je Profil eine minimale config.yaml — ohne die wird das Profil vom
#      Kanban-Dispatcher NICHT als Assignee erkannt
#
# Das Skript ist idempotent: mehrfaches Ausführen ist unschädlich.
# Rückbau: ./teardown.sh
#
# Getestet mit: Hermes Agent v0.20.0 (2026.8.3) auf macOS
#
set -euo pipefail

BOARD="kanban-tutorial"

# Profilname : Beschreibung (die Beschreibung nutzt der Kanban-Decomposer,
# um Aufgaben nach Rolle statt nach Namen zu routen).
PROFILE_NAMES=(backend-dev qa-dev translator transcriber copywriter pm reviewer deploy-bot)

describe_backend_dev="Backend engineer. Designs database schemas, writes migrations, implements REST/HTTP API endpoints in Python and TypeScript, and handles auth, sessions and tokens."
describe_qa_dev="QA engineer. Writes integration and end-to-end tests, designs test matrices covering happy path and edge cases, and verifies API contracts."
describe_translator="Translator. Translates marketing and product copy between English, German, Spanish and French while preserving tone and terminology."
describe_transcriber="Transcriber. Turns audio and call notes into clean, structured written transcripts with speaker labels and timestamps."
describe_copywriter="Copywriter. Writes short product descriptions, marketing headlines and e-commerce copy from product attribute data."
describe_pm="Product manager. Turns rough feature ideas into concrete specs with goal, scope, user-visible behaviour and testable acceptance criteria."
describe_reviewer="Code reviewer. Reviews diffs and pull requests for correctness, security and missing tests, and either approves or lists concrete required changes."
describe_deploy_bot="Deployment bot. Runs deployments to staging and production using cloud CLIs and requires cloud credentials in its environment."

description_for() {
    local var="describe_${1//-/_}"
    printf '%s' "${!var}"
}

say() { printf '\n\033[1m%s\033[0m\n' "$*"; }

# ---------------------------------------------------------------------------
# 0. Vorbedingungen prüfen
# ---------------------------------------------------------------------------
say "0/4  Vorbedingungen prüfen"

command -v hermes >/dev/null || { echo "FEHLER: 'hermes' nicht im PATH."; exit 1; }
hermes --version | head -1

command -v jq >/dev/null || {
    echo "FEHLER: 'jq' fehlt. Installieren mit:  brew install jq"
    exit 1
}
echo "jq: $(command -v jq)"

# ---------------------------------------------------------------------------
# 1. Board anlegen
# ---------------------------------------------------------------------------
say "1/4  Board '$BOARD' anlegen"

if hermes kanban boards list 2>/dev/null | grep -q "^[● ] *${BOARD} "; then
    echo "Board '$BOARD' existiert bereits — übersprungen."
else
    hermes kanban boards create "$BOARD" \
        --name "Kanban Tutorial" \
        --description "Sandbox-Board fuer das Hermes Kanban Tutorial" \
        --icon "🎓"
fi

# ---------------------------------------------------------------------------
# 2. Modell-Einstellungen der Root-Installation auslesen
# ---------------------------------------------------------------------------
say "2/4  Modell-Einstellungen aus der Root-Konfiguration übernehmen"

MODEL_KEYS=(model.default model.provider model.base_url model.api_mode)
declare -a ROOT_VALUES=()

for key in "${MODEL_KEYS[@]}"; do
    value="$(hermes config get "$key" 2>/dev/null | head -1 || true)"
    case "$value" in
        ""|"Config key not set"*) value="" ;;
    esac
    ROOT_VALUES+=("$value")
    printf '  %-18s = %s\n' "$key" "${value:-<nicht gesetzt>}"
done

[ -n "${ROOT_VALUES[0]}" ] || {
    echo "FEHLER: model.default ist in der Root-Konfiguration nicht gesetzt."
    echo "        Führe zuerst 'hermes setup' aus."
    exit 1
}

# ---------------------------------------------------------------------------
# 3. Profile anlegen + konfigurieren
# ---------------------------------------------------------------------------
say "3/4  Acht Tutorial-Profile anlegen"

for name in "${PROFILE_NAMES[@]}"; do
    if [ -d "$HOME/.hermes/profiles/$name" ]; then
        echo "  $name — Verzeichnis existiert, überspringe 'profile create'"
    else
        hermes profile create "$name" \
            --no-skills \
            --description "$(description_for "$name")" >/dev/null
        echo "  $name — angelegt"
    fi

    # Die config.yaml ist der entscheidende Schritt: erst mit ihr taucht das
    # Profil in 'hermes kanban assignees' auf und ist damit dispatchbar.
    for i in "${!MODEL_KEYS[@]}"; do
        [ -n "${ROOT_VALUES[$i]}" ] || continue
        hermes -p "$name" config set "${MODEL_KEYS[$i]}" "${ROOT_VALUES[$i]}" >/dev/null
    done
    echo "      config.yaml geschrieben ($(hermes -p "$name" config get model.default 2>/dev/null | head -1))"
done

# ---------------------------------------------------------------------------
# 4. Verifikation
# ---------------------------------------------------------------------------
say "4/4  Verifikation — alle acht Profile müssen 'ON DISK = yes' zeigen"

hermes kanban --board "$BOARD" assignees

missing=0
for name in "${PROFILE_NAMES[@]}"; do
    if ! hermes kanban --board "$BOARD" assignees | awk '{print $1, $2}' | grep -q "^${name} yes$"; then
        echo "FEHLER: Profil '$name' ist nicht 'ON DISK' — fehlt die config.yaml?"
        missing=1
    fi
done

if [ "$missing" -eq 0 ]; then
    printf '\n\033[32m✓ Setup vollständig. Weiter mit "Story 1 - Solo Dev".\033[0m\n'
else
    printf '\n\033[31m✗ Setup unvollständig — siehe Fehler oben.\033[0m\n'
    exit 1
fi
