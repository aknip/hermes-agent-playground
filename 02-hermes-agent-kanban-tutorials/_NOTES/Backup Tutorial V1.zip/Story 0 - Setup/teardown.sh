#!/usr/bin/env bash
#
# Story 0 — Teardown: entfernt Tutorial-Artefakte aus der Hermes-Installation
# ==========================================================================
#
# Drei Stufen, über Optionen wählbar:
#
#   ./teardown.sh                 alles: Board + Profile + Arbeitsdateien
#   ./teardown.sh --keep-profiles Board + Arbeitsdateien (Profile bleiben)
#   ./teardown.sh --files-only    NUR Arbeitsdateien (Board UND Profile bleiben)
#
#   -y / --yes                    ohne Rückfrage
#
# --files-only ist der Modus zum Aufräumen zwischen zwei Stories: es bleibt
# alles bestehen, was die nächste Story braucht.
#
# Es wird NICHTS außerhalb dieser Liste angefasst — dein default-Board, deine
# eigenen Profile und deine Root-Konfiguration bleiben unberührt.
#
set -euo pipefail

BOARD="kanban-tutorial"
PROFILE_NAMES=(backend-dev qa-dev translator transcriber copywriter pm reviewer deploy-bot)
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TUTORIAL_ROOT="$(cd "$HERE/.." && pwd)"

ASSUME_YES=0
REMOVE_BOARD=1
REMOVE_PROFILES=1

for arg in "$@"; do
    case "$arg" in
        -y|--yes)        ASSUME_YES=1 ;;
        --keep-profiles) REMOVE_PROFILES=0 ;;
        --files-only)    REMOVE_PROFILES=0; REMOVE_BOARD=0 ;;
        *) echo "Unbekannte Option: $arg"; exit 1 ;;
    esac
done

say() { printf '\n\033[1m%s\033[0m\n' "$*"; }

say "Es werden entfernt:"
if [ "$REMOVE_BOARD" -eq 1 ]; then
    echo "  • Kanban-Board:  $BOARD  (inkl. Tasks, Runs, Events, Logs, Workspaces)"
else
    echo "  • Kanban-Board:  bleibt erhalten"
fi
if [ "$REMOVE_PROFILES" -eq 1 ]; then
    echo "  • Profile:       ${PROFILE_NAMES[*]}"
else
    echo "  • Profile:       bleiben erhalten"
fi
echo "  • Arbeitsdateien: alle Story-workspace/ werden aus seed/ neu aufgebaut"

if [ "$ASSUME_YES" -eq 0 ]; then
    printf '\nFortfahren? [j/N] '
    read -r answer
    case "$answer" in
        j|J|y|Y) ;;
        *) echo "Abgebrochen."; exit 0 ;;
    esac
fi

# ---------------------------------------------------------------------------
# 1. Board entfernen
# ---------------------------------------------------------------------------
say "1/3  Board"

if [ "$REMOVE_BOARD" -eq 0 ]; then
    echo "  übersprungen"
else
    # Falls das Tutorial-Board gerade das aktive ist, erst zurück auf default.
    if hermes kanban boards show 2>/dev/null | head -1 | grep -qx "Current board: ${BOARD}"; then
        hermes kanban boards switch default >/dev/null
        echo "  Aktives Board zurück auf 'default' gesetzt."
    fi

    if hermes kanban boards list 2>/dev/null | grep -q "^[● ] *${BOARD} "; then
        # --delete entfernt das Board-Verzeichnis wirklich;
        # ohne das Flag wird nur nach boards/_archived/ verschoben.
        hermes kanban boards rm "$BOARD" --delete
    else
        echo "  Board '$BOARD' existiert nicht (mehr) — übersprungen."
    fi

    BOARD_DIR="$HOME/.hermes/kanban/boards/$BOARD"
    if [ -d "$BOARD_DIR" ]; then
        rm -rf "$BOARD_DIR"
        echo "  Restverzeichnis $BOARD_DIR gelöscht."
    fi
fi

# ---------------------------------------------------------------------------
# 2. Profile entfernen
# ---------------------------------------------------------------------------
say "2/3  Profile"

if [ "$REMOVE_PROFILES" -eq 0 ]; then
    echo "  übersprungen"
else
    for name in "${PROFILE_NAMES[@]}"; do
        if [ -d "$HOME/.hermes/profiles/$name" ]; then
            hermes profile delete "$name" -y >/dev/null 2>&1 \
                && echo "  $name — gelöscht" \
                || echo "  $name — 'hermes profile delete' schlug fehl, räume von Hand auf"
            # Sicherheitsnetz, falls delete nur teilweise durchlief:
            rm -rf "$HOME/.hermes/profiles/$name"
            rm -f  "$HOME/.local/bin/$name"
        else
            echo "  $name — nicht vorhanden, übersprungen"
        fi
    done
fi

# ---------------------------------------------------------------------------
# 3. Arbeitsdateien
# ---------------------------------------------------------------------------
say "3/3  Arbeitsverzeichnisse aus seed/ neu aufbauen"

echo "  Vorher — was Worker verändert oder erzeugt haben:"
"$HERE/reset-workspaces.sh" --diff | sed 's/^/  /'
echo
"$HERE/reset-workspaces.sh" | sed 's/^/  /'

# ---------------------------------------------------------------------------
say "Kontrolle"
echo "Boards:"
hermes kanban boards list 2>/dev/null | sed 's/^/  /'
echo
echo "Profile:"
hermes profile list 2>/dev/null | sed 's/^/  /'
echo
echo "Arbeitsverzeichnisse (muss leer sein — keine Abweichung gegen seed/):"
"$HERE/reset-workspaces.sh" --diff | sed 's/^/  /'

printf '\n\033[32m✓ Teardown abgeschlossen.\033[0m\n'
