# Spezifikation: Passwort-Reset (miniauth)

## Ziel

Angemeldete und abgemeldete Nutzer des `miniauth`-Moduls sollen ihr Passwort
eigenständig und sicher zurücksetzen können, ohne dass ein Administrator
eingreifen muss. Der Flow wird ausschließlich über einen zeitlich begrenzten,
**single-use** Einmal-Token abgewickelt, der per E-Mail versendet wird. Nach
erfolgreichem Reset werden alle aktiven Sessions des betroffenen Kontos
invalidiert.

Implementiert wird der Flow im Modul `auth/reset.py` über die drei bereits
vorgegebenen Funktionen:

- `forgot_password(conn, email)` — versendet einen Reset-Token
- `render_reset_form(conn, token)` — prüft den Token und rendert das Formular
- `apply_reset(conn, token, new_pw)` — setzt das neue Passwort

Die Abläufe unten sind als HTTP-Endpunkte spezifiziert; die drei Funktionen
bilden die zugehörige Logik dahinter ab.

## Ablauf

### 1. Token anfordern — `POST /forgot-password`

Eingabe (Formular): `email`

1. Der Server prüft, ob zur `email` ein Konto existiert.
2. Wenn ein Konto existiert, wird ein kryptografisch sicherer Token erzeugt und
   mit einer **Gültigkeitsdauer von 30 Minuten** (Konstante
   `RESET_TOKEN_TTL_SECONDS = 30 * 60`) assoziiert und gespeichert.
3. Der Server versendet eine E-Mail mit einem Reset-Link, der den Token
   enthält: `https://<host>/reset/<token>`.
4. Aus Gründen der Benutzerfreundlichkeit und um Account-Enumeration zu
   erschweren, antwortet der Endpunkt in **beiden Fällen** (Konto vorhanden /
   nicht vorhanden) mit derselben Erfolgsmeldung („Falls ein Konto existiert,
   wurde ein Reset-Link versendet.“).

### 2. Reset-Formular anzeigen — `GET /reset/:token`

1. Der Server validiert den Token (existiert, nicht abgelaufen, nicht bereits
   eingelöst).
2. Ist der Token gültig, wird das Formular mit den Feldern `new_password` und
   `new_password_confirmation` gerendert.
3. Ist der Token ungültig, abgelaufen oder bereits eingelöst, wird eine
   verständliche Fehlermeldung angezeigt (z. B. „Link ungültig oder
   abgelaufen“) und **kein** Formular.

### 3. Neues Passwort setzen — `POST /reset`

Eingabe (Formular): `token`, `new_password`, `new_password_confirmation`

1. Der Token wird erneut validiert (existiert, nicht abgelaufen, nicht bereits
   eingelöst).
2. `new_password` und `new_password_confirmation` müssen übereinstimmen.
3. Das neue Passwort muss die **Mindestanforderungen** erfüllen (siehe
   Akzeptanzkriterium AK-1).
4. Ist alles gültig, wird das neue Passwort (gehasht) gespeichert.
5. Der Token wird **sofort invalidiert** (`single-use`), d. h. ein zweiter
   Aufruf mit demselben Token schlägt fehl.
6. Alle aktiven Sessions des Nutzers werden invalidiert.
7. Erfolgsantwort: der Nutzer kann sich mit dem neuen Passwort anmelden.

## Akzeptanzkriterien

- **AK-1 — Passwortstärke:** `POST /reset` lehnt ein Passwort ab, das kürzer
  als 8 Zeichen ist, ein triviales/gefährdetes Passwort darstellt (z. B.
  `password`, `12345678`) oder der E-Mail-Adresse des Kontos zu ähnlich ist
  (z. B. exakter lokaler Teil als Passwort). Bei Ablehnung wird keine Nutzer-
  Datenbank-Änderung vorgenommen.

- **AK-2 — Token ist single-use:** Nach einem erfolgreichen Reset ist derselbe
  Token ungültig. Ein zweiter `POST /reset` mit demselben Token innerhalb der
  ursprünglichen 30-Minuten-Frist wird abgelehnt, und das Passwort bleibt
  unverändert.

- **AK-3 — Token-Ablauf:** Nach Ablauf von `RESET_TOKEN_TTL_SECONDS` (30
  Minuten) lehnen `GET /reset/:token` und `POST /reset` den Token ab; es kann
  kein Passwort mit einem abgelaufenen Token geändert werden.

- **AK-4 — Sessions werden invalidiert:** Nach erfolgreichem Reset sind alle
  zuvor aktiven Sessions des Nutzers ungültig; ein Client mit einem vorherigen
  Session-Token erhält bei der nächsten Anfrage eine 401/„nicht
  authentifiziert“-Antwort und muss sich mit dem neuen Passwort anmelden.

- **AK-5 — Keine Account-Enumeration:** `POST /forgot-password` gibt für eine
  nicht existierende E-Mail dieselbe Antwort wie für eine existierende (kein
  Hinweis auf die Existenz des Kontos).

- **AK-6 — Passwort-Bestätigung:** `POST /reset` wird abgelehnt, wenn
  `new_password` und `new_password_confirmation` nicht übereinstimmen, und
  setzt kein neues Passwort.

Jedes Kriterium ist einzeln testbar: AK-1, AK-2, AK-3, AK-4, AK-5 und AK-6
lassen sich mit Unit- bzw. Integrationstests direkt gegen `reset.py` bzw. die
HTTP-Endpunkte verifizieren.
