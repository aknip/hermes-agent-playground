# Hermes Kanban — Schritt für Schritt

Nachgespielte und korrigierte Fassung des offiziellen
[Kanban-Tutorials](https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban-tutorial),
verifiziert gegen **Hermes Agent v0.20.0 (2026.8.3)** auf **macOS**
(Darwin 25.5.0, Python 3.11.15).

Die Oberflächen-Matrix (Terminal / Web-Dashboard / Desktop-App) steht im
[README](README.md). Was ich real ausgeführt habe und was nicht, steht in
[VERIFIKATION.md](VERIFIKATION.md).

---

## Inhalt

- [Wie dieses Tutorial zu lesen ist](#wie-dieses-tutorial-zu-lesen-ist)
- [Das Grundmodell in fünf Begriffen](#das-grundmodell-in-fünf-begriffen)
- [Story 0 — Setup (Pflicht)](#story-0--setup-pflicht)
- [Story 1 — Solo Dev: Abhängigkeiten und Handoff](#story-1--solo-dev-abhängigkeiten-und-handoff)
- [Story 2 — Fleet Farming: zwölf Tasks, drei Spezialisten](#story-2--fleet-farming-zwölf-tasks-drei-spezialisten)
- [Story 3 — Rollen-Pipeline mit Retry](#story-3--rollen-pipeline-mit-retry)
- [Story 4 — Circuit Breaker und Crash Recovery](#story-4--circuit-breaker-und-crash-recovery)
- [Das Board hat 8 Spalten, nicht 6](#das-board-hat-8-spalten-nicht-6)
- [Rückbau — alle Artefakte entfernen](#rückbau--alle-artefakte-entfernen)
- [Befehlsreferenz](#befehlsreferenz)

---

## Wie dieses Tutorial zu lesen ist

**Codeblöcke mit `bash` sind Befehle, die *du* eintippst.** Sie laufen alle im
Terminal, im jeweiligen Story-Verzeichnis.

**Codeblöcke mit `# Worker-Tool-Calls` sind das, was der gespawnte Agent
intern aufruft.** Die tippt niemand ein — sie stehen hier nur, damit du den
Kreis schließen kannst. Diese Werkzeuge (`kanban_show`, `kanban_complete`,
`kanban_block`, `kanban_heartbeat`, …) existieren ausschließlich innerhalb
eines Worker-Prozesses. Der Worker sieht weder das Dashboard noch die CLI.

Jede Story endet mit **„Das solltest du sehen"** — daran prüfst du, ob es
funktioniert hat — und mit **„Aufräumen"**.

Ein `⚠` markiert eine Stelle, an der diese Fassung bewusst von der offiziellen
Doku abweicht, weil das Original in 0.20.0 nicht (mehr) zutrifft.

---

## Das Grundmodell in fünf Begriffen

| Begriff | Bedeutung |
|---|---|
| **Board** | Eine isolierte SQLite-Warteschlange. Das Standard-Board liegt in `~/.hermes/kanban.db`, jedes weitere unter `~/.hermes/kanban/boards/<slug>/kanban.db`. Worker eines Boards können Tasks anderer Boards physisch nicht sehen. |
| **Task** | Eine Zeile mit Titel, Body, Assignee, Status und optionalem Tenant. Kann Eltern-Tasks haben. |
| **Assignee** | Der **Profilname**, der den Task ausführen soll — nicht eine Person. `backend-dev` ist ein Hermes-Profil. |
| **Run** | Ein Ausführungsversuch. Drei Versuche = drei Runs, jeder mit eigenem Outcome, Summary und Metadata. Die Historie ist die primäre Darstellung, kein Nachgedanke. |
| **Dispatcher** | Die Schleife, die zugewiesene Tasks beansprucht, das Profil als eigenständigen OS-Prozess startet, tote Worker einsammelt und `todo`-Tasks nach `ready` befördert, wenn deren Eltern fertig sind. |

Der entscheidende Unterschied zu `delegate_task`: Kanban-Tasks überleben
Neustarts, sind für Menschen einsehbar und behalten eine dauerhafte
Audit-Spur. `delegate_task` blockiert, bis der Unteragent fertig ist.

---

## Story 0 — Setup (Pflicht)

Das offizielle Tutorial beginnt mit `hermes kanban init` und
`hermes dashboard`. Das ist zu wenig: es benutzt ab Story 1 die Profile
`backend-dev`, `qa-dev`, `translator`, `transcriber`, `copywriter`, `pm`,
`reviewer` und `deploy-bot`, ohne zu sagen, dass es sie anlegen muss.

### ⚠ Die Falle: `hermes profile create` allein genügt nicht

Ein Profil gilt für den Kanban-Dispatcher nur dann als vorhandener Assignee,
wenn im Profilverzeichnis eine **`config.yaml`** liegt. So prüft Hermes das
(aus `hermes_cli/kanban_db.py`, `list_profiles_on_disk`):

```
if (entry / "config.yaml").is_file():
    names.add(entry.name)
```

`hermes profile create` legt aber `.env`, `SOUL.md` und `profile.yaml` an —
**keine `config.yaml`**. Folge: Das Profil erscheint in `hermes profile list`,
aber nicht in `hermes kanban assignees`, und Tasks für dieses Profil bleiben
für immer auf `ready` liegen, ohne Fehlermeldung.

Der Nachweis, gemessen auf einem frisch erzeugten Profil:

```console
$ hermes profile create backend-dev --no-skills --description "…"
Profile 'backend-dev' created at /Users/…/.hermes/profiles/backend-dev

$ hermes kanban --board kanban-tutorial assignees
NAME                  ON DISK   COUNTS
default               yes       (idle)
developer             yes       (idle)
summarizer            yes       (idle)          ← backend-dev fehlt!

$ hermes -p backend-dev config set model.default "deepseek/deepseek-v4-flash-0731"
✓ Set model.default = … in /Users/…/.hermes/profiles/backend-dev/config.yaml

$ hermes kanban --board kanban-tutorial assignees
NAME                  ON DISK   COUNTS
backend-dev           yes       (idle)          ← jetzt da
default               yes       (idle)
…
```

Die zweite Falle: `hermes -p <profil> config set model.default …` schreibt nur
diesen einen Schlüssel. `model.provider`, `model.base_url` und `model.api_mode`
fehlen dann und werden aus den eingebauten Defaults gefüllt — was zu einem
anderen Provider führen kann als dein Root-Profil benutzt. Deshalb setzt das
Setup-Skript alle vier Schlüssel und liest sie aus deiner Root-Konfiguration.

Ein API-Key im Profil ist übrigens **nicht** nötig: die Profile erben die
Schlüssel aus der Umgebung. Das habe ich verifiziert — der erste Worker lief
mit leerer `~/.hermes/profiles/backend-dev/.env` durch.

### Schritt 0.1 — Vorbedingungen prüfen

```bash
hermes --version                    # v0.20.0 (2026.8.3) oder neuer
jq --version                        # sonst: brew install jq
hermes config get model.default     # darf nicht leer sein
```

### Schritt 0.2 — Setup ausführen

```bash
cd "Story 0 - Setup"
chmod +x setup.sh teardown.sh pump.sh
./setup.sh
```

Das Skript liegt als [`Story 0 - Setup/setup.sh`](Story%200%20-%20Setup/setup.sh)
bei. Es macht vier Dinge:

1. Board `kanban-tutorial` anlegen (idempotent).
2. `model.default`, `model.provider`, `model.base_url`, `model.api_mode` aus
   deiner Root-Konfiguration auslesen.
3. Acht Profile anlegen (`--no-skills`, mit `--description`) und die vier
   Modell-Schlüssel in jedes hineinschreiben.
4. Verifizieren, dass alle acht in `hermes kanban assignees` mit
   `ON DISK = yes` erscheinen — sonst bricht es mit Fehler ab.

Wenn du es lieber selbst tippst, ist das der Kern:

```bash
hermes kanban boards create kanban-tutorial --name "Kanban Tutorial" --icon "🎓"

hermes profile create backend-dev --no-skills \
  --description "Backend engineer. Designs database schemas, writes migrations, implements REST/HTTP API endpoints in Python and TypeScript, and handles auth, sessions and tokens."

for key in model.default model.provider model.base_url model.api_mode; do
  hermes -p backend-dev config set "$key" "$(hermes config get "$key")"
done
```

…und das dann für die restlichen sieben Profile mit deren Beschreibungen.

### Die Profilbeschreibungen

`--description` ist kein Kommentar. Der **Kanban-Decomposer** liest diese
Texte, um einen Triage-Task auf die passenden Spezialisten zu verteilen — er
routet über die Beschreibung, nicht über den Profilnamen. Nachträglich ändern:
`hermes profile describe <profil> --text "…"`, oder automatisch generieren mit
`hermes profile describe --all --auto`.

Die acht Beschreibungen, die dieses Tutorial verwendet (sie liegen auch in
[`Story 0 - Setup/profiles/`](Story%200%20-%20Setup/profiles/)):

| Profil | Beschreibung |
|---|---|
| `backend-dev` | Backend engineer. Designs database schemas, writes migrations, implements REST/HTTP API endpoints in Python and TypeScript, and handles auth, sessions and tokens. |
| `qa-dev` | QA engineer. Writes integration and end-to-end tests, designs test matrices covering happy path and edge cases, and verifies API contracts. |
| `translator` | Translator. Translates marketing and product copy between English, German, Spanish and French while preserving tone and terminology. |
| `transcriber` | Transcriber. Turns audio and call notes into clean, structured written transcripts with speaker labels and timestamps. |
| `copywriter` | Copywriter. Writes short product descriptions, marketing headlines and e-commerce copy from product attribute data. |
| `pm` | Product manager. Turns rough feature ideas into concrete specs with goal, scope, user-visible behaviour and testable acceptance criteria. |
| `reviewer` | Code reviewer. Reviews diffs and pull requests for correctness, security and missing tests, and either approves or lists concrete required changes. |
| `deploy-bot` | Deployment bot. Runs deployments to staging and production using cloud CLIs and requires cloud credentials in its environment. |

### Schritt 0.3 — Oberfläche öffnen

**Web-Dashboard** (entspricht den Screenshots der offiziellen Doku):

```bash
hermes dashboard          # öffnet http://127.0.0.1:9119
# dann links im Menü auf "Kanban", oben Board "Kanban Tutorial" wählen
```

Stoppen mit `hermes dashboard --stop`, Status mit `hermes dashboard --status`.

**Desktop-App:** `/Applications/Hermes.app` starten, dann
**Settings ▸ Plugins ▸ Kanban einschalten** — das Board ist dort
standardmäßig **aus**. Danach erscheint „Kanban" in der Seitenleiste.

### Schritt 0.4 — Der Dispatcher

Damit überhaupt etwas passiert, muss jemand den Dispatcher laufen lassen. Drei
Wege:

```bash
# a) Gateway — der Normalfall. Enthält den Dispatcher, Tick alle 60 s,
#    bedient ALLE Boards (auch neu angelegte).
hermes gateway start

# b) Ein einzelner Tick, sofort. Entspricht "Nudge dispatcher" im Dashboard.
hermes kanban --board kanban-tutorial dispatch

# c) Die Tutorial-Pumpe: Tick alle 15 s, bis nichts mehr offen ist.
#    Nur für dieses Board, jederzeit mit Ctrl-C abbrechbar.
cd "Story 0 - Setup" && ./pump.sh
```

Für das Tutorial ist **(c)** am angenehmsten: 60 Sekunden Wartezeit pro Schritt
summieren sich sonst erheblich. `hermes kanban daemon` ist in 0.20.0
**deprecated** — der Dispatcher lebt im Gateway.

⚠ **Läuft bei dir ein Gateway, startet es Tasks auch ohne dein Zutun** — und
zwar auf **jedem** Board, auch auf einem gerade neu angelegten. Das habe ich
zweimal beobachtet: einmal übernahm es den ersten Task von Story 2 sofort nach
dem Anlegen, einmal ließ es eine Wegwerf-Aufgabe komplett durchlaufen, obwohl
ich sie nur trocken prüfen wollte.

Praktisch heißt das: du kannst einen Task nicht „erst mal anlegen und später
ansehen", solange ein Gateway läuft. Wenn du das brauchst, lege ihn geparkt an
und befördere ihn erst, wenn du fertig bist:

```bash
hermes kanban --board kanban-tutorial create "…" --assignee backend-dev --triage
# oder nach dem Anlegen:
hermes kanban --board kanban-tutorial block <id> --reason "noch nicht starten"
…
hermes kanban --board kanban-tutorial unblock <id>
```

Gateway-Zustand prüfen bzw. anhalten:

```bash
hermes gateway status
hermes gateway stop
```

Vorher ansehen, was ein Tick tun *würde*:

```bash
hermes kanban --board kanban-tutorial dispatch --dry-run
```

```console
Reclaimed:    0
Crashed:      0
Timed out:    0
Stale:        0
Auto-blocked: 0
Promoted:     0
Spawned:      1
  - t_21263ef2  ->  backend-dev  @ - (dry)
```

### Das solltest du sehen

```bash
hermes kanban --board kanban-tutorial assignees
```

Alle acht Tutorial-Profile mit `ON DISK = yes`. Fehlt eines, fehlt seine
`config.yaml`.

### Aufräumen

Noch nichts — Story 0 ist die Grundlage für alle weiteren. Der komplette
Rückbau steht am Ende dieses Dokuments.

---

## Story 1 — Solo Dev: Abhängigkeiten und Handoff

Klassischer Ablauf eines einzelnen Entwicklers: Schema entwerfen, API
implementieren, Tests schreiben. Drei Tasks in einer Kette.

```
Design auth schema  →  Implement auth API endpoints  →  Write auth integration tests
     backend-dev              backend-dev                        qa-dev
```

Worum es fachlich geht: **Nur der erste Task startet.** Die beiden anderen
warten, bis ihr jeweiliger Eltern-Task fertig ist. Und: der zweite Worker
bekommt das *Ergebnis* des ersten strukturiert vorgelegt, statt ein
Design-Dokument neu lesen zu müssen. Das ist der „structured handoff".

### Die Arbeitsdateien

In [`Story 1 - Solo Dev/`](Story%201%20-%20Solo%20Dev/) liegt ein absichtlich
leeres Mini-Projekt — zweimal:

```
Story 1 - Solo Dev/
├── seed/              unveränderlicher Master
└── workspace/         Arbeitskopie; hier arbeiten die Worker
    ├── README.md          Projektbeschreibung für die Worker
    ├── auth/
    │   └── __init__.py    leeres Paket — hier landet die Implementierung
    ├── migrations/        leer — hier landen die SQL-Migrationen
    └── tests/             leer — hier landen die Tests
```

Beide haben denselben Inhalt. `seed/` fasst niemand an; `workspace/` lässt sich
daraus jederzeit wiederherstellen (`Story 0 - Setup/reset-workspaces.sh`). Das
ist nötig, weil der API-Worker `auth/__init__.py` **überschreibt**.

`workspace/README.md`:

```markdown
# miniauth — Übungsprojekt für Story 1

Ein absichtlich leeres Mini-Projekt. Die Kanban-Worker füllen es.

Aufgabe des Projekts: ein minimaler Authentifizierungs-Baustein mit
Registrierung, Login, Token-Refresh und Logout. Bewusst ohne Framework —
es geht um die Kanban-Mechanik, nicht um Web-Frameworks.

Die drei Kanban-Tasks der Story hängen voneinander ab:

    Design auth schema  →  Implement auth API endpoints  →  Write auth integration tests
         backend-dev              backend-dev                        qa-dev
```

`workspace/auth/__init__.py`:

```python
"""miniauth — Authentifizierungs-Baustein.

Startdatei des Tutorials. Der API-Worker aus Story 1 füllt dieses Paket
mit den Endpunkten register / login / refresh / logout.
"""

__all__: list[str] = []
```

### Schritt 1.1 — Die drei Tasks anlegen

```bash
cd "Story 1 - Solo Dev"
chmod +x create-tasks.sh
./create-tasks.sh
```

Das Skript ist
[`Story 1 - Solo Dev/create-tasks.sh`](Story%201%20-%20Solo%20Dev/create-tasks.sh).
Die drei Aufrufe im Kern — beachte `--parent`:

```bash
BOARD=kanban-tutorial
WS="$PWD/workspace"

SCHEMA=$(hermes kanban --board $BOARD create "Design auth schema" \
    --assignee backend-dev --tenant auth-project --priority 2 \
    --workspace "dir:$WS" \
    --body "Entwirf das Schema für users, sessions und refresh tokens …" \
    --json | jq -r .id)

API=$(hermes kanban --board $BOARD create "Implement auth API endpoints" \
    --assignee backend-dev --tenant auth-project --priority 2 \
    --parent "$SCHEMA" \
    --workspace "dir:$WS" \
    --body "POST /register, POST /login, POST /refresh, POST /logout …" \
    --json | jq -r .id)

hermes kanban --board $BOARD create "Write auth integration tests" \
    --assignee qa-dev --tenant auth-project --priority 2 \
    --parent "$API" \
    --workspace "dir:$WS" \
    --body "Happy Path, falsches Passwort, abgelaufener Token, paralleler Refresh …"
```

Zwei Dinge, die das Original nicht sagt:

- `--workspace dir:<pfad>` **muss absolut sein**. Relative Pfade werden
  abgewiesen (sonst würden sie gegen das Arbeitsverzeichnis des Dispatchers
  auflösen). Ohne `--workspace` bekommt jeder Task ein eigenes
  Wegwerf-Verzeichnis (`scratch`) und du siehst das Ergebnis nur im Summary.
- Der Task-Body ist der Auftrag an das Modell. Je konkreter (welche Dateien,
  welches Format, was ins `metadata`), desto brauchbarer das Ergebnis.

Das Skript schreibt die IDs nach `task-ids.env`, damit die folgenden Schritte
sie wiederverwenden können:

```bash
source task-ids.env      # setzt BOARD, SCHEMA, API, TESTS
```

### Schritt 1.2 — Ausgangszustand prüfen

```bash
hermes kanban --board $BOARD list --tenant auth-project
```

Real gemessen:

```console
Board: kanban-tutorial (1 other board — `hermes kanban boards list`)

▶ t_f92e2974  ready     backend-dev          [auth-project]  Design auth schema
◻ t_94cb365d  todo      backend-dev          [auth-project]  Implement auth API endpoints
◻ t_7793e530  todo      qa-dev               [auth-project]  Write auth integration tests
```

Genau wie dokumentiert: **einer auf `ready`, zwei auf `todo`.** Das ist die
Dependency-Promotion-Engine — niemand schreibt Tests, solange es keine API gibt.

**Im Dashboard:** die Karte „Design auth schema" steht in *Ready*, die anderen
zwei in *Todo*. Klick auf eine Karte öffnet den Drawer rechts; unter
*Dependencies* siehst du „blocked by".

### Schritt 1.3 — Arbeiten lassen

```bash
cd "../Story 0 - Setup" && ./pump.sh
```

oder ein einzelner Tick:

```bash
hermes kanban --board $BOARD dispatch
```

**Im Dashboard:** „Nudge dispatcher" oben rechts.

Der Dispatcher beansprucht `$SCHEMA`, startet das Profil `backend-dev` als
eigenen OS-Prozess und setzt `HERMES_KANBAN_TASK=$SCHEMA` in dessen Umgebung.

### Was im Worker passiert

Diese Aufrufe macht das Modell im Worker-Prozess — **nicht du**:

```python
# Worker-Tool-Calls — KEINE Befehle für dein Terminal
kanban_show()
# → Titel, Body, worker_context, Eltern-Ergebnisse, frühere Versuche, Kommentare

# (der Worker liest Dateien, schreibt die Migrationen, prüft sie —
#  hier passiert die eigentliche Arbeit)

kanban_heartbeat(note="Schema entworfen, schreibe jetzt die Migrationen")

kanban_complete(
    summary="users(id, email, pw_hash), sessions(id, user_id, jti, expires_at); "
            "Refresh-Tokens als sessions mit kind='refresh'",
    metadata={
        "changed_files": ["migrations/001_users.sql", "migrations/002_sessions.sql"],
        "decisions": ["bcrypt zum Hashen", "JWT als Session-Token"],
    },
)
```

`kanban_show()` braucht keine Task-ID — es füllt sie aus
`$HERMES_KANBAN_TASK`. `kanban_complete()` schreibt Summary und Metadata auf
die aktuelle `task_runs`-Zeile, schließt den Run und setzt den Task in einem
atomaren Schritt auf `done`.

Du kannst dem Worker live über die Schulter schauen:

```bash
hermes kanban --board $BOARD log $SCHEMA --tail 2000
```

### Schritt 1.4 — Den Handoff sichtbar machen

Das ist der lehrreichste Befehl des ganzen Tutorials — und er fehlt im
Original: **`hermes kanban context`** zeigt genau das, was der Worker sieht.

Vor dem Abschluss des Eltern-Tasks:

```bash
hermes kanban --board $BOARD context $API
```

```console
# Kanban task t_94cb365d: Implement auth API endpoints

Assignee: backend-dev
Status:   todo
Tenant:   auth-project
Workspace: dir @ /Users/…/Story 1 - Solo Dev/workspace

## Body
Implementiere die vier Endpunkte des miniauth-Moduls: …
```

Kein Eltern-Abschnitt. Nach dem Abschluss von `$SCHEMA` derselbe Befehl —
jetzt kommt der entscheidende Block hinzu (real gemessen, gekürzt):

```console
## Parent task results
_Handoffs from upstream tasks, captured when each parent completed …_
### t_f92e2974 (completed just now)
Auth-Schema entworfen und als SQLite-Migrationen implementiert:
users(id, email, pw_hash, created_at) und sessions(id, user_id→users.id,
jti UNIQUE, kind CHECK access/refresh, expires_at). Beide DDLs gegen eine
echte SQLite-DB verifiziert.
_metadata_: `{"changed_files": ["migrations/001_users.sql",
"migrations/002_sessions.sql"], "decisions": ["users: email UNIQUE und NOT
NULL", "sessions deckt access UND refresh über kind-Spalte ab", …]}`

## Recent work by @backend-dev
- t_f92e2974 — Design auth schema (just now): Auth-Schema entworfen …
```

**Das ist der Kern von Kanban gegenüber einer flachen Todo-Liste.** Der
API-Worker liest die Schema-Entscheidungen strukturiert, statt sich durch
Kommentare und Arbeitsergebnisse zu wühlen. Der Abschnitt
„Recent work by @<profil>" ist eine Zugabe von 0.20.0, die in der Doku nicht
erwähnt wird.

### Schritt 1.5 — Ergebnis inspizieren

```bash
hermes kanban --board $BOARD runs $SCHEMA
```

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  completed     backend-dev             1m  2026-08-10 08:22
     → Auth-Schema entworfen und als SQLite-Migrationen implementiert: users(id, …
```

```bash
hermes kanban --board $BOARD show $SCHEMA
```

zeigt zusätzlich das vollständige Event-Log — die eigentliche Audit-Spur:

```console
Events (5):
  [08:22] created {'assignee': 'backend-dev', 'status': 'ready', 'parents': [], …}
  [08:22] [run 1] claimed {'lock': 'ANSGARKMAC2:80555', 'expires': …, 'run_id': 1}
  [08:22] [run 1] spawned {'pid': 80736}
  [08:22] [run 1] heartbeat
  [08:23] [run 1] completed {'summary': 'Auth-Schema entworfen und als …'}

Runs (1):
  #1   completed    @backend-dev  65s  2026-08-10 08:22
```

**Im Dashboard:** derselbe Inhalt im Drawer, Abschnitt *Run History* bzw.
*Activity*.

### Das solltest du sehen

```bash
hermes kanban --board $BOARD list --tenant auth-project
find workspace -type f | sort
```

Alle drei Tasks auf `done`, und im Arbeitsverzeichnis echte Dateien. Real
entstanden (gesamte Kette: knapp 4 Minuten, je ein Run pro Task):

```console
✓ t_f92e2974  done      backend-dev          [auth-project]  Design auth schema
✓ t_94cb365d  done      backend-dev          [auth-project]  Implement auth API endpoints
✓ t_7793e530  done      qa-dev               [auth-project]  Write auth integration tests

workspace/README.md
workspace/auth/__init__.py
workspace/auth/api.py                 ← vom API-Worker
workspace/migrations/001_users.sql    ← vom Schema-Worker
workspace/migrations/002_sessions.sql ← vom Schema-Worker
workspace/tests/test_auth.py          ← vom QA-Worker (14 Tests)
```

Der QA-Worker hat die Endpunktnamen aus dem Eltern-Handoff übernommen, ohne
`auth/api.py` vorher lesen zu müssen — genau das ist der Punkt.

### Aufräumen

```bash
source task-ids.env
hermes kanban --board $BOARD archive $SCHEMA $API $TESTS
```

Arbeitsverzeichnis zurücksetzen. Jede Story hat ein unveränderliches
`seed/`-Verzeichnis; `workspace/` ist nur die Arbeitskopie:

```bash
cd "../Story 0 - Setup"
./reset-workspaces.sh --diff                  # erst ansehen, was entstanden ist
./reset-workspaces.sh "Story 1 - Solo Dev"    # dann nur diese Story zurücksetzen
```

⚠ **Nicht** `./teardown.sh` benutzen, wenn du noch weitermachen willst — das
löscht das Board und damit die Grundlage von Story 2–4. Für „nur Dateien
aufräumen, alles andere behalten" gibt es:

```bash
./teardown.sh --files-only -y
```

Warum ein `seed/`-Verzeichnis und nicht einfach „lösche die neuen Dateien"?
Weil Worker auch **Startdateien überschreiben**: der API-Worker aus Story 1
schreibt `auth/__init__.py` neu. Nur mit einer unangetasteten Kopie ist die
Story beliebig oft wiederholbar.

---

## Story 2 — Fleet Farming: zwölf Tasks, drei Spezialisten

Der einfachste Anwendungsfall und der, für den Kanban ursprünglich gebaut
wurde: ein Haufen **unabhängiger** Aufgaben, drei Spezialisten, alle sollen
gleichzeitig ziehen.

```
translator    3 Tasks   Homepage nach ES / FR / DE
transcriber   5 Tasks   fünf rohe Gesprächsnotizen aufbereiten
copywriter    4 Tasks   vier Produkttexte aus SKU-Daten
```

Kein `--parent`, keine Abhängigkeiten: alle zwölf stehen sofort auf `ready`.

### Die Arbeitsdateien

In [`Story 2 - Fleet Farming/seed/`](Story%202%20-%20Fleet%20Farming/seed/) —
und als Arbeitskopie in `workspace/`:

```
workspace/
├── source/homepage.md      englische Marketing-Seite (Vorlage zum Übersetzen)
├── calls/call-1.txt … 5    fünf rohe, unstrukturierte Gesprächsmitschriften
├── products/skus.csv       vier Produkte mit Attributen
├── translations/           leer — Ziel der Übersetzer
├── transcripts/            leer — Ziel der Transkribierer
└── descriptions/           leer — Ziel der Texter
```

`products/skus.csv` — bewusst nur Fakten, damit man erkennt, ob ein Texter
etwas dazuerfindet:

```csv
sku,name,category,material,colour,weight_g,key_feature,price_eur
SKU-1001,Trailhead 30L Daypack,Backpacks,recycled ripstop nylon,slate blue,780,ventilated back panel with removable frame,129.00
SKU-1002,Kettle Peak Insulated Bottle,Drinkware,18/8 stainless steel,matte sand,410,keeps drinks cold 24h / hot 12h,34.90
SKU-1003,Fieldnote Hardcover Journal,Stationery,recycled paper 120gsm,forest green,320,lay-flat binding with numbered pages,18.50
SKU-1004,Ridgeline Merino Beanie,Headwear,merino wool blend,charcoal,85,itch-free flatlock seam,27.00
```

Die fünf `calls/call-N.txt` sind absichtlich hässlich — Kleinschreibung,
Abkürzungen, Gedankensprünge, eingestreute `action:`-Zeilen. Genau daran zeigt
sich, ob der Transkribierer strukturiert statt halluziniert. Auszug aus
`calls/call-2.txt`:

```
Q3 CUSTOMER CALL — RAW NOTES
acct: Halden Logistics / enterprise trial, day 19 of 30
who: Tobias (head of data eng), Sam (analyst)

tobias opens with: "we're not going to buy this if the API rate limit stays"
       — hitting 429s on backfill, 5k events/min ceiling
       their backfill is 40M events, math doesnt work
...
sentiment: at risk — technical blocker is real, not a negotiating tactic
```

### Schritt 2.1 — Die zwölf Tasks anlegen

```bash
cd "Story 2 - Fleet Farming"
chmod +x create-tasks.sh
./create-tasks.sh
```

Der Kern von
[`create-tasks.sh`](Story%202%20-%20Fleet%20Farming/create-tasks.sh) — beachte,
dass hier **kein** `--parent` vorkommt:

```bash
BOARD=kanban-tutorial
WS="$PWD/workspace"

for lang in Spanish French German; do
    hermes kanban --board $BOARD create "Translate homepage to $lang" \
        --assignee translator --tenant content-ops \
        --workspace "dir:$WS" \
        --body "Übersetze source/homepage.md nach $lang → translations/homepage.<code>.md …"
done

for i in 1 2 3 4 5; do
    hermes kanban --board $BOARD create "Transcribe Q3 customer call #$i" \
        --assignee transcriber --tenant content-ops \
        --workspace "dir:$WS" \
        --body "Bereite calls/call-$i.txt zu transcripts/call-$i.md auf …"
done

for sku in 1001 1002 1003 1004; do
    hermes kanban --board $BOARD create "Generate product description: SKU-$sku" \
        --assignee copywriter --tenant content-ops \
        --workspace "dir:$WS" \
        --body "Schreibe descriptions/SKU-$sku.md aus products/skus.csv …"
done
```

Das offizielle Tutorial benutzt hier dieselbe Schleifenstruktur. Der Unterschied
ist nur `--workspace`, damit die Ergebnisse als Dateien landen.

### Schritt 2.2 — Laufen lassen und weggehen

Das Original sagt an dieser Stelle:

```bash
hermes gateway start
```

Das stimmt und ist der Normalfall: das Gateway enthält den Dispatcher und
bedient **alle** Boards. Ich habe das verifiziert — kaum war das Board erzeugt,
hat der Gateway-Dispatcher von selbst den ersten Task übernommen, ohne dass ich
irgendetwas auf das neue Board zeigen musste.

Für ein Tutorial ist der 60-Sekunden-Takt aber zäh. Schneller:

```bash
cd "../Story 0 - Setup" && ./pump.sh
```

### Schritt 2.3 — Beim Arbeiten zusehen

```bash
hermes kanban --board kanban-tutorial list --tenant content-ops
hermes kanban --board kanban-tutorial stats
hermes kanban --board kanban-tutorial watch --kinds completed,blocked,gave_up
```

`stats` ist die Fleet-Übersicht, die im Original nur als Randnotiz auftaucht:

```console
By status:
  triage    0
  todo      1
  scheduled  0
  ready     0
  running   1
  blocked   0
  done      16

By assignee:
  backend-dev           done=2, running=1
  copywriter            done=4
  pm                    done=1
  qa-dev                done=1
  transcriber           done=5
  translator            done=3
```

**Im Dashboard:** oben auf `content-ops` filtern. Die Spalte *In progress* ist
mit „Lanes by profile" (Standard) nach Assignee unterteilt — du siehst pro
Worker eine eigene Bahn statt einer gemischten Liste. Schaltest du den Regler
aus, wird eine flache Liste nach Claim-Zeitpunkt daraus.

### Das solltest du sehen

Real gemessen: **alle zwölf Tasks starteten um 08:34**, also im selben
Dispatch-Fenster, und waren nach rund vier Minuten Wanduhrzeit fertig — je
ein Run, kein Fehlversuch:

```console
  1  completed     translator             48s  2026-08-10 08:34
  1  completed     translator             59s  2026-08-10 08:34
  1  completed     translator             57s  2026-08-10 08:34
  1  completed     transcriber             4m  2026-08-10 08:34
  1  completed     transcriber             1m  2026-08-10 08:34
  1  completed     transcriber             1m  2026-08-10 08:34
  1  completed     transcriber             1m  2026-08-10 08:34
  1  completed     transcriber             3m  2026-08-10 08:34
  1  completed     copywriter              1m  2026-08-10 08:34
  1  completed     copywriter              1m  2026-08-10 08:34
  1  completed     copywriter              1m  2026-08-10 08:34
  1  completed     copywriter              1m  2026-08-10 08:34
```

Und zwölf neue Dateien:

```bash
diff -rq seed workspace          # oder: ../"Story 0 - Setup"/reset-workspaces.sh --diff
```

```console
workspace/descriptions/SKU-1001.md … SKU-1004.md
workspace/transcripts/call-1.md … call-5.md
workspace/translations/homepage.de.md
workspace/translations/homepage.es.md
workspace/translations/homepage.fr.md
```

Stichprobe `translations/homepage.de.md` — Markdown-Struktur erhalten, Ton
übertragen statt wörtlich übersetzt:

```markdown
# Northwind Analytics — Startseite

## Hero

**Schluss mit Raten. Jetzt wissen.**

Northwind Analytics macht aus deinem rohen Event-Stream Entscheidungen, die du
im Vorstand verteidigen kannst. Verbinde eine Quelle in vier Minuten und sieh
dein erstes Dashboard, bevor dein Kaffee kalt wird.
```

Stichprobe `descriptions/SKU-1002.md` — alle Zahlen stammen aus der CSV:

```markdown
# Kettle Peak Insulated Bottle

Ob auf der Wanderung oder im Alltag: Die Kettle Peak Insulated Bottle … Gefertigt
aus 18/8 Edelstahl in der Farbe matte sand, bringt die Flasche nur 410 g auf die
Waage. …

- Haelt Getraenke 24 Stunden kalt bzw. 12 Stunden heiss
- Gefertigt aus langlebigem 18/8 Edelstahl
- Leichtes Gewicht von nur 410 g in der Farbe matte sand

Preis: 34,90 EUR
```

Alles, was Story 1 über den strukturierten Handoff gesagt hat, gilt hier
weiter: jeder dieser Worker hat `kanban_complete(summary=…, metadata=…)`
aufgerufen. Sichtbar mit:

```bash
hermes kanban --board kanban-tutorial show <id> | grep -A3 "Latest summary"
```

Nützlich für Auswertungen — und unverzichtbar, sobald doch ein Task von einem
dieser Ergebnisse abhängt.

### Aufräumen

```bash
hermes kanban --board kanban-tutorial list --tenant content-ops --json \
  | jq -r '.[].id' \
  | xargs hermes kanban --board kanban-tutorial archive
```

Dateien zurücksetzen:

```bash
cd "../Story 0 - Setup"
./reset-workspaces.sh --diff                       # zwölf neue Dateien sichtbar
./reset-workspaces.sh "Story 2 - Fleet Farming"    # zurücksetzen
```

---

## Story 3 — Rollen-Pipeline mit Retry

Hier verdient Kanban sein Geld gegenüber einer flachen Todo-Liste. Ein PM
schreibt eine Spezifikation. Ein Entwickler implementiert sie. Der Review lehnt
den ersten Versuch ab. Der Entwickler versucht es erneut — und weiß dabei
**genau**, was am ersten Versuch fehlte.

```
Spec: password reset flow  →  Implement password reset flow  →  Review password reset PR
          pm                          backend-dev                      reviewer
                                    (blockiert, dann Retry)
```

### ⚠ Wie diese Story reproduzierbar wird

Das offizielle Tutorial zeigt, wie der Engineer-Worker `kanban_block()` aufruft,
weil „Review-Feedback eintrifft". Wann ein Modell von sich aus blockiert, ist
aber nicht steuerbar — nachspielen lässt sich das so nicht.

Diese Fassung erzwingt es über eine Regel im Task-Body, die auf den
**Worker-Kontext** zugreift:

> Sieh nach, ob es bereits frühere Versuche zu diesem Task gibt.
> – **Nein:** implementiere, lies dann `REVIEW-FEEDBACK.md` und rufe
>   `kanban_block()` mit diesen Punkten auf.
> – **Ja:** lies den Block-Grund und arbeite genau diese Punkte ab, dann
>   `kanban_complete()`.

Damit ist der Ablauf deterministisch — **und** die Regel demonstriert
gleichzeitig die Kernaussage: der Worker im zweiten Versuch sieht, warum der
erste scheiterte.

### Die Arbeitsdateien

In [`Story 3 - Role Pipeline/seed/`](Story%203%20-%20Role%20Pipeline/seed/):

```
seed/
├── README.md            erklärt den Mechanismus
├── REVIEW-FEEDBACK.md   die offenen Review-Punkte — der Block-Auslöser
├── spec/                leer — Ziel des PM-Workers
└── auth/reset.py        leerer Stub — Ziel des Engineer-Workers
```

`REVIEW-FEEDBACK.md` — bewusst zwei blockierende und ein nicht-blockierender
Punkt, damit man sieht, ob der Worker unterscheidet:

```markdown
# Review-Feedback zum Passwort-Reset (offen)

Status: **OFFEN** — zwei Punkte blockieren das Merge.

1. **Passwortstärke wird nicht geprüft.**
   `POST /reset` akzeptiert jedes nicht-leere Passwort. Es fehlt eine
   Mindestprüfung (Länge, Trivialpasswörter, Ähnlichkeit zur E-Mail-Adresse).

2. **Der Reset-Link ist nicht single-use.**
   Der Token bleibt bis zum Ablauf (30 Minuten) gültig und kann innerhalb
   dieses Fensters mehrfach eingelöst werden. Er muss beim ersten
   erfolgreichen Reset invalidiert werden.

Nicht blockierend, aber erwünscht:

- Nach erfolgreichem Reset sollten alle aktiven Sessions des Nutzers
  invalidiert werden.
```

`auth/reset.py`:

```python
"""Passwort-Reset — Startdatei des Tutorials.

Der Engineer-Worker aus Story 3 füllt dieses Modul mit den drei Schritten
des Reset-Flows:

    forgot_password(conn, email)        -> versendet einen Reset-Token
    render_reset_form(conn, token)      -> prüft den Token
    apply_reset(conn, token, new_pw)    -> setzt das neue Passwort

Bewusst leer gelassen.
"""

RESET_TOKEN_TTL_SECONDS = 30 * 60
```

### Schritt 3.1 — Die Pipeline anlegen

```bash
cd "Story 3 - Role Pipeline"
chmod +x create-tasks.sh
./create-tasks.sh
source task-ids.env       # setzt BOARD, SPEC, IMPL, REVIEW
```

Wichtig am PM-Task: er wird ausdrücklich angewiesen, die Akzeptanzkriterien
**zusätzlich als Liste ins `metadata` unter `acceptance`** zu legen. Genau
dieses Feld liest der Engineer-Worker später aus dem Eltern-Handoff:

```bash
hermes kanban --board $BOARD create "Spec: password reset flow" \
    --assignee pm --tenant reset-feature --priority 1 \
    --workspace "dir:$PWD/workspace" \
    --body "… Wichtig: lege die Akzeptanzkriterien ZUSÄTZLICH als Liste in
metadata unter dem Schlüssel 'acceptance' ab — der Engineer-Worker liest
genau dieses Feld aus dem Parent-Handoff."
```

### Schritt 3.2 — PM und erster Implementierungsversuch

```bash
cd "../Story 0 - Setup" && ./pump.sh
```

Der PM-Worker lief bei mir in gut einer Minute durch und legte fünf
Akzeptanzkriterien ab. Danach beförderte die Engine `$IMPL` automatisch von
`todo` auf `ready` — sichtbar als Event `promoted`.

Der Engineer-Worker arbeitete dann **13 Minuten** und blockierte am Ende:

```bash
hermes kanban --board $BOARD runs $IMPL
```

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  blocked       backend-dev            13m  2026-08-10 08:28
     → Review-Feedback (siehe REVIEW-FEEDBACK.md) — offene Punkte blockieren das
       Merge: (1) Passwortstärke wird nicht geprüft … (2) Der Reset-Link ist
       nicht single-use …
```

Was der Worker dabei tat (**nicht** von dir eingetippt):

```python
# Worker-Tool-Calls
kanban_show()     # liest die acceptance-Liste aus dem Parent-Handoff
# (implementiert forgot_password / render_reset_form / apply_reset)
kanban_heartbeat(...)   # 13× im Minutentakt — hält den Claim lebendig
kanban_block(
    reason="Review-Feedback … (1) Passwortstärke … (2) nicht single-use …",
)
```

Im Event-Log sieht man die Heartbeats und den Block mit
`kind: 'needs_input'`:

```console
  [08:28] [run 5] claimed {'lock': 'ANSGARKMAC2:14418', 'run_id': 5}
  [08:28] [run 5] spawned {'pid': 14623}
  [08:29] [run 5] heartbeat
  …                                    (13 Heartbeats)
  [08:41] [run 5] blocked {'reason': 'Review-Feedback …', 'kind': 'needs_input',
                           'recurrences': 1}
```

Die Heartbeats sind kein Zierrat: ohne sie würde der Dispatcher den Claim nach
`kanban.dispatch_stale_timeout_seconds` für verwaist halten.

**Im Dashboard:** die Karte steht jetzt in *Blocked*, im Drawer steht der
Block-Grund unter dem Outcome von Run 1.

### Schritt 3.3 — Entblocken

Du (oder ein separates Reviewer-Profil) liest den Grund, hältst die Richtung
für klar und gibst den Task frei:

```bash
hermes kanban --board $BOARD unblock $IMPL
```

```console
Unblocked t_f8504ceb
```

**Im Dashboard:** „Unblock" im Drawer. **Aus einem Chat heraus:**
`/kanban unblock <id>`.

Der Task geht nach `ready`, der nächste Tick startet `backend-dev` neu — als
**neuer Run auf demselben Task**.

### Schritt 3.4 — Der Handoff des Fehlversuchs

Bevor du weiterlaufen lässt: sieh dir an, was der zweite Worker vorgesetzt
bekommt.

```bash
hermes kanban --board $BOARD context $IMPL
```

Real gemessen — jetzt stehen **drei** Abschnitte drin:

```console
## Prior attempts on this task
### Attempt 1 — blocked (backend-dev, 2026-08-10 08:28, 14m ago)
Review-Feedback … (1) Passwortstärke wird nicht geprüft … (2) Der Reset-Link
ist nicht single-use …

## Parent task results
### t_401a67c8 (completed 15m ago)
Spezifikation für den Passwort-Reset des miniauth-Moduls geschrieben …
_metadata_: {"acceptance": [
  "AC-1: POST /forgot-password mit registrierter E-Mail erzeugt Token und
         antwortet 200 OK; nicht registrierte E-Mail liefert identische
         Antwort (kein Enumeration-Leak).",
  "AC-2: GET /reset/:token … 400 Bad Request …",
  "AC-3: POST /reset … macht Token einwegig; zweite Verwendung → 400 …",
  "AC-4: … Richtlinie nicht genügt → 422 …",
  "AC-5: … erst nach erfolgreichem POST /reset ist das Token verbraucht."],
  "changed_files": ["spec/password-reset.md"]}

## Recent work by @backend-dev
- …
```

Der zweite Worker weiß also **ohne Rückfrage**: was gefordert war (PM),
was gefehlt hat (Run 1) und was er selbst zuletzt getan hat.

### Schritt 3.5 — Zweiter Versuch und Review

```bash
cd "../Story 0 - Setup" && ./pump.sh
```

Real gemessen — und das ist der Beweis für die Behauptung der Doku:

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  blocked       backend-dev            13m  2026-08-10 08:28
  2  completed     backend-dev             4m  2026-08-10 08:43
     → Zweiter Versuch: Die beiden blockierenden Review-Punkte in auth/reset.py
       behoben und per Test gegen eine echte sqlite3-In-Memory-DB verifiziert
       (18/18 Checks, alle 5 Akzeptanzkriterien) …
```

**13 Minuten für den ersten Versuch, 4 Minuten für den zweiten.** Der zweite
Worker hat nicht von vorne angefangen, sondern die zwei benannten Punkte
abgearbeitet — genau das, was die Doku mit „addresses those specific findings
instead of re-running from scratch" meint, hier als Messwert.

Das `metadata` von Run 2, real:

```json
{
  "changed_files": ["auth/reset.py", "REVIEW-FEEDBACK.md"],
  "review_iteration": 2,
  "acceptance_verified": ["AC-1", "AC-2", "AC-3", "AC-4", "AC-5"],
  "password_strength_checks": ["laenge", "komplexitaet", "trivialpasswoerter",
                               "email_aehnlichkeit"],
  "single_use_token": true,
  "sessions_invalidated_on_reset": true
}
```

Jeder Run ist eine eigene Zeile in `task_runs` mit eigenem Outcome, Summary und
Metadata. Die Retry-Historie ist nicht nachträglich über einen
„aktueller-Zustand"-Task gelegt — sie **ist** die Darstellung.

Anschließend wird `$REVIEW` automatisch nach `ready` befördert. Der
Reviewer-Worker sieht im Eltern-Handoff „Passwortstärke-Prüfung ergänzt,
Token jetzt single-use" und hat die Liste der geänderten Dateien in der Hand,
bevor er in einen Diff schaut.

### Das solltest du sehen

```bash
hermes kanban --board $BOARD list --tenant reset-feature
hermes kanban --board $BOARD runs $IMPL
cd "../Story 0 - Setup" && ./reset-workspaces.sh --diff
```

- Alle drei Tasks auf `done`.
- `$IMPL` mit **zwei** Runs: `blocked`, dann `completed`.
- Neu im Arbeitsverzeichnis: `spec/password-reset.md`,
  ein ausgefülltes `auth/reset.py`, `REVIEW-FEEDBACK.md` mit Status
  **ERLEDIGT** statt OFFEN, und das Urteil des Reviewers in
  `REVIEW-VERDICT.md`.

Ein Nebeneffekt, der beim Vergleichen zweier Ausgaben irritiert:
`hermes kanban runs` numeriert die Versuche eines Tasks fortlaufend ab 1,
`hermes kanban show` zeigt dagegen die board-globale `run_id` — im Test
„Runs (1): #5" für denselben Versuch, den `runs` als „1" führt.

### Aufräumen

```bash
source task-ids.env
hermes kanban --board $BOARD archive $SPEC $IMPL $REVIEW
cd "../Story 0 - Setup" && ./reset-workspaces.sh "Story 3 - Role Pipeline"
```

---

## Story 4 — Circuit Breaker und Crash Recovery

Worker scheitern. Fehlende Zugangsdaten, OOM-Kills, kaputte Pfade,
Netzwerkfehler. Der Dispatcher hat dafür **drei** Verteidigungslinien — die
offizielle Doku beschreibt nur zwei.

| Mechanismus | Wann | Ergebnis |
|---|---|---|
| **Circuit Breaker** | N Fehlversuche in Folge bei einem *wiederholbaren* Fehler | Run-Outcome `gave_up`, Task-Status `blocked` |
| **Respawn-Sperre** | Fehlertext sieht nach Auth/Quota aus | **gar kein** neuer Versuch, Task bleibt `ready` |
| **Crash-Erkennung** | Worker-Prozess ist weg, TTL noch nicht abgelaufen | Run-Outcome `crashed`, Task zurück auf `ready` |

### ⚠ Warum das AWS-Beispiel der Doku nicht funktioniert

Die Doku legt einen Task an, dessen Profil kein `AWS_ACCESS_KEY_ID` hat, und
behauptet, der Spawn scheitere mit `RuntimeError: AWS_ACCESS_KEY_ID not set`.
In 0.20.0 ist das nicht so: eine fehlende Umgebungsvariable verhindert den
Spawn nicht — der Worker startet und scheitert allenfalls zur Laufzeit.

`spawn_failed` entsteht im Dispatcher an genau zwei Stellen: wenn die
**Workspace-Auflösung** eine Exception wirft, oder wenn der **Prozess-Spawn**
selbst eine wirft. Beide Teilversuche unten benutzen den ersten Weg, mit zwei
verschiedenen Fehlertexten — weil der Fehlertext entscheidet, welcher der
beiden Schutzmechanismen greift.

**Beide Teile von 4a kosten keine Tokens:** der Fehler tritt auf, bevor das
Modell gestartet wird.

### Die Arbeitsdateien

Teil 4a braucht keine — der Spawn scheitert, bevor irgendwer ein Verzeichnis
betritt. Teil 4b (Crash Recovery) braucht eine Aufgabe, die lange genug läuft,
um den Worker mitten in der Arbeit zu erwischen. Dafür liegt in
[`Story 4 - Circuit Breaker/seed/`](Story%204%20-%20Circuit%20Breaker/seed/):

```
seed/
├── data/events.csv    420 Zeilen synthetische Ereignisdaten, 10 Kategorien
└── reports/           leer — Ziel des Workers
```

`data/events.csv` (Auszug):

```csv
event_id,ts,category,duration_ms,outcome,account
ev_00001,2026-07-01T08:07:00,search,2680,ok,acct_122
ev_00002,2026-07-01T08:14:00,signup,72,ok,acct_103
```

Erzeugen lässt sie sich mit diesem Schnipsel — nützlich, wenn du die Menge
verändern willst, um die Laufzeit zu treffen:

```python
import csv, random, datetime
random.seed(20260810)
cats = ["checkout","search","signup","billing","export",
        "dashboard","api","email","upload","settings"]
outcomes = ["ok","ok","ok","ok","slow","error"]
start = datetime.datetime(2026, 7, 1, 8, 0, 0)
rows = [{
    "event_id": f"ev_{i:05d}",
    "ts": (start + datetime.timedelta(minutes=7 * i)).isoformat(timespec="seconds"),
    "category": cats[i % len(cats)],
    "duration_ms": random.randint(35, 4200),
    "outcome": random.choice(outcomes),
    "account": f"acct_{random.randint(100, 140)}",
} for i in range(1, 421)]
with open("data/events.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
```

### Schritt 4a — Circuit Breaker

```bash
cd "Story 4 - Circuit Breaker"
chmod +x breaker.sh crash.sh
./breaker.sh
```

Der Kern von [`breaker.sh`](Story%204%20-%20Circuit%20Breaker/breaker.sh):

```bash
hermes kanban --board kanban-tutorial create \
    "Deploy to staging (Zielpfad ist kein Verzeichnis)" \
    --assignee deploy-bot --tenant ops \
    --workspace "dir:/dev/null/staging" \
    --max-retries 3 \
    --body "…"
```

`/dev/null` ist eine Gerätedatei, kein Verzeichnis. `mkdir -p` darunter wirft
`NotADirectoryError` (Errno 20). Dieser Text enthält **kein** Auth- oder
Quota-Muster — die Respawn-Sperre greift also nicht, und der Dispatcher
versucht es jedes Mal erneut, bis der Breaker zuschlägt.

Real gemessen:

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  spawn_failed  deploy-bot              0s  2026-08-10 08:39
     ✖ workspace: [Errno 20] Not a directory: '/dev/null/staging'
  2  spawn_failed  deploy-bot              0s  2026-08-10 08:39
     ✖ workspace: [Errno 20] Not a directory: '/dev/null/staging'
  3  gave_up       deploy-bot              0s  2026-08-10 08:39
     ✖ workspace: [Errno 20] Not a directory: '/dev/null/staging'
```

Event-Log — **identisch zu dem, was die offizielle Doku beschreibt**:

```console
created → claimed → spawn_failed → claimed → spawn_failed → claimed → gave_up
```

Die ersten zwei Runs sind `spawn_failed` (wiederholbar), der dritte ist
`gave_up` (endgültig). Task-Status danach: `blocked`. Ohne `--max-retries`
gilt `kanban.failure_limit` aus der Konfiguration — bei dir **2**.

So findest du solche Fälle, ohne das Board abzusuchen:

```bash
hermes kanban --board kanban-tutorial diagnostics
```

```console
1 active diagnostic(s) across 1 task(s):

  t_009b64eb  blocked   @deploy-bot   Deploy to staging …
    !! [error] repeated_failures: Agent spawn x3: workspace: [Errno 20] Not a
       directory: '/dev/null/staging'
       data: consecutive_failures=3 | most_recent_outcome=spawn_failed
             | failure_threshold=2 | failure_limit=2
       → Verify profile: hermes -p deploy-bot doctor
```

Zurückholen:

```bash
hermes kanban --board kanban-tutorial unblock t_009b64eb    # → ready
```

Wenn Telegram, Discord oder Slack angebunden sind, feuert beim `gave_up`-Event
eine Gateway-Benachrichtigung. (Das habe ich **nicht** getestet — siehe
VERIFIKATION.md.)

### Schritt 4a-2 — Die Respawn-Sperre (in keiner Doku)

`breaker.sh` fährt danach einen zweiten Fall: derselbe Aufbau, aber der Pfad
liegt auf einem **nicht gemounteten** Netzlaufwerk.

```bash
--workspace "dir:/Volumes/deploy-share/staging"
```

Auf macOS liefert `mkdir` dort `PermissionError` (Errno 13). Und jetzt kommt
der Unterschied. Vor jedem Spawn läuft `check_respawn_guard` und vergleicht den
letzten Fehlertext mit diesem Muster (aus `kanban_db.py`):

```python
_RESPAWN_BLOCKER_RE = re.compile(
    r"\b(quota|rate[\s_\-]?limit|429|403|auth\w*|"
    r"unauthorized|forbidden|billing|subscription|"
    r"access[\s_]denied|permission[\s_]denied|"
    r"invalid[\s_]api[\s_]key)\b", re.IGNORECASE)
```

„Permission denied" passt darauf. Der Dispatcher stuft den Fehler damit als
„durch Wiederholen nicht lösbar" ein und versucht es **überhaupt nicht mehr**.
Real gemessen, über drei Dispatch-Ticks:

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  spawn_failed  deploy-bot              0s  2026-08-10 08:39
     ✖ workspace: [Errno 13] Permission denied: '/Volumes/deploy-share'

Events: created → claimed → spawn_failed → respawn_guarded → respawn_guarded
```

Kein zweiter Versuch. Kein `gave_up`. **Task-Status bleibt `ready`.**

Das ist die unangenehmere Fehlerart: die Karte sieht auf dem Board aus wie
„wartet auf den Dispatcher", wird aber nie wieder angefasst. Und —
verifiziert — **`hermes kanban diagnostics` meldet diesen Fall nicht.** Nur das
Event-Log verrät ihn:

```bash
hermes kanban --board kanban-tutorial show <id> --json \
  | jq -r '.events[].kind'
```

Steht dort `respawn_guarded`, ist der Task gesperrt. Weitere Sperrgründe im
selben Wächter: ein erfolgreicher Run innerhalb der letzten Stunde, eine
GitHub-PR-URL in einem Kommentar innerhalb von 24 Stunden, und ein
Rate-Limit-Cooldown von 300 Sekunden.

### Schritt 4b — Crash Recovery

Manchmal gelingt der Spawn, aber der Prozess stirbt später — Segfault, OOM,
`systemctl stop`. Der Dispatcher pollt `kill(pid, 0)`, erkennt die tote PID,
gibt den Claim frei und schickt den Task zurück auf `ready`.

⚠ Die Doku nimmt als Beispiel einen OOM-Kill bei 2,3 Mio. Zeilen. Ein echter
OOM lässt sich nicht verlässlich herbeiführen; `kill -9` löst **denselben**
Erkennungspfad aus (tote PID) und ist reproduzierbar. Das ist die einzige
Abweichung.

```bash
./crash.sh          # tötet den Worker 25 s nach dem Spawn
./crash.sh 10       # aggressiver, falls dein Modell schneller ist
```

Was [`crash.sh`](Story%204%20-%20Circuit%20Breaker/crash.sh) tut:

1. Legt einen Task an, der lange genug läuft: `data/events.csv` (420 Zeilen) in
   zehn Kategorie-Reports zerlegen, **Datei für Datei**, damit Teilfortschritt
   erhalten bleibt.
2. `hermes kanban dispatch` — Worker startet.
3. Liest die PID aus dem Event-Log:
   ```bash
   hermes kanban --board kanban-tutorial show $MIG --json \
     | jq -r '[.events[] | select(.kind=="spawned") | .payload.pid] | last'
   ```
4. Wartet, dann `kill -9 <pid>`.
5. `hermes kanban dispatch` — der Dispatcher erkennt die tote PID.
6. `hermes kanban dispatch` — zweiter Versuch.

Der Task-Body enthält außerdem die Anweisung, bei einem früheren abgestürzten
Versuch erst zu prüfen, welche Reports schon existieren, und dort weiterzumachen.

Real gemessen:

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  crashed       backend-dev            32s  2026-08-10 08:43
     ✖ pid 98251 not alive
  2  completed     backend-dev             1m  2026-08-10 08:44
     → data/events.csv (420 Zeilen) in 10 Kategorie-Reports zerlegt und
       reports/SUMMARY.md erstellt …
```

Event-Log, mit den Run-Wechseln:

```console
  [run 28] claimed
  [run 28] spawned
  [run 28] heartbeat
  [run 28] crashed
  [run 29] claimed
  [run 29] spawned
  [run 29] heartbeat
  [run 29] heartbeat
  [run 29] completed
```

Der abgestürzte Versuch verschwindet **nicht**. Er bleibt als Zeile in
`task_runs` stehen, mit `pid 98251 not alive` im `error`-Feld — auch Monate
später noch für eine Ursachenanalyse lesbar.

### Verwandt: `reclaim` und `--max-runtime`

Zwei Wege, die ohne Crash auskommen:

```bash
# Claim eines hängenden Workers von Hand freigeben:
hermes kanban --board kanban-tutorial reclaim <id>

# Laufzeitdeckel schon beim Anlegen: nach 30 Minuten SIGTERM, dann SIGKILL,
# Task zurück in die Queue (Outcome 'timed_out'):
hermes kanban --board kanban-tutorial create "Langer Import" \
    --assignee backend-dev --max-runtime 30m
```

`spawn_failed`, `timed_out` und `crashed` zählen alle auf denselben
Fehlerzähler des Circuit Breakers. Ein Task, der dreimal in eine Zeitschranke
läuft, wird also genauso blockiert wie einer, der dreimal nicht startet.

### Das solltest du sehen

```bash
hermes kanban --board kanban-tutorial list --tenant ops
hermes kanban --board kanban-tutorial diagnostics
ls workspace/reports/
```

- Der Breaker-Task auf `blocked`, drei Runs, letzter `gave_up`.
- Der gesperrte Task auf `ready`, ein Run, danach nur `respawn_guarded`.
- Der Crash-Task auf `done`, zwei Runs: `crashed`, dann `completed`.
- Elf Dateien in `workspace/reports/`: zehn Kategorien plus `SUMMARY.md`.

**In der Oberfläche:** Diese Story ist die terminal-lastigste. Beide grafischen
Oberflächen zeigen die Karten in *Blocked* bzw. *Ready* und im Drawer die Runs
mit ihren Outcomes — aber weder die eine noch die andere hat ein Gegenstück zu
`hermes kanban diagnostics`, und den Unterschied zwischen „wartet auf den
Dispatcher" und „ist durch die Respawn-Sperre stillgelegt" siehst du dort
nicht. Für Fehlersuche gilt: Terminal.

### Aufräumen

```bash
hermes kanban --board kanban-tutorial list --tenant ops --json \
  | jq -r '.[].id' \
  | xargs hermes kanban --board kanban-tutorial archive

cd "../Story 0 - Setup" && ./reset-workspaces.sh "Story 4 - Circuit Breaker"
```

---

## Das Board hat 8 Spalten, nicht 6

Die offizielle Doku beschreibt sechs Spalten: Triage, Todo, Ready, In progress,
Blocked, Done. Das ist in 0.20.0 **nicht mehr vollständig**.

Der Statusvorrat in `hermes_cli/kanban_db.py`:

```python
VALID_STATUSES = {"triage", "todo", "scheduled", "ready", "running",
                  "blocked", "review", "done", "archived"}
```

Und die Spaltenreihenfolge, die beide Oberflächen rendern
(`plugins/kanban/dashboard/plugin_api.py`):

```python
BOARD_COLUMNS: list[str] = [
    "triage", "todo", "scheduled", "ready", "running", "blocked", "review", "done",
]
```

Die zwei zusätzlichen Spalten:

| Spalte | Bedeutung | Wie kommt ein Task hinein? |
|---|---|---|
| **Scheduled** | Wartet auf **Zeit**, nicht auf einen Menschen. Absichtlich nicht dispatchbar — ein externer Auslöser (Cron, Gateway) holt den Task zurück. | `hermes kanban schedule <id> --reason "…"` |
| **Review** | Ein Worker hat einen PR erzeugt und den Task zur Prüfung weitergegeben. Der Dispatcher startet dafür einen Review-Agenten mit der Skill `sdlc-review`, der entweder merged (→ `done`) oder zurückgibt (→ `running`). | Worker-seitig im SDLC-Ablauf |

`archived` ist ein neunter Status, aber keine Spalte — archivierte Tasks
verschwinden aus der Ansicht (`--archived` bzw. der Schalter
„Show archived" holt sie zurück).

Praktischer Unterschied zwischen `blocked` und `scheduled`:

```bash
hermes kanban --board kanban-tutorial block <id> --reason "brauche Entscheidung von dir"
hermes kanban --board kanban-tutorial schedule <id> --reason "erst nach dem Release am Freitag"
hermes kanban --board kanban-tutorial unblock <id>    # holt BEIDE zurück
```

`unblock` bringt einen Task nach `ready` — oder nach `todo`, falls noch offene
Eltern-Tasks existieren.

---

## Rückbau — alle Artefakte entfernen

Das Tutorial hinterlässt genau drei Arten von Artefakten: ein Board, acht
Profile (samt Wrapper-Skripten) und von Workern erzeugte Dateien. Hier steht,
wie du jede Art loswirst — erst der schnelle Weg, dann jeder Schritt von Hand,
damit du nachvollziehen kannst, was das Skript tut.

### Der schnelle Weg

```bash
cd "Story 0 - Setup"
./teardown.sh
```

Das Skript ([`teardown.sh`](Story%200%20-%20Setup/teardown.sh)) fragt einmal
nach und entfernt dann Board, Profile, Wrapper und Worker-Dateien. Drei Stufen:

| Aufruf | Board | Profile | Arbeitsdateien |
|---|---|---|---|
| `./teardown.sh` | gelöscht | gelöscht | zurückgesetzt |
| `./teardown.sh --keep-profiles` | gelöscht | bleiben | zurückgesetzt |
| `./teardown.sh --files-only` | bleibt | bleiben | zurückgesetzt |

`-y` überspringt die Rückfrage.

⚠ **Zwischen zwei Stories immer `--files-only` benutzen.** Ohne diese Option
löscht das Skript das Board — und damit die Grundlage der noch folgenden
Stories.

Verifiziert, in dieser Reihenfolge durchgeführt:
`--files-only` (Board und alle acht Profile blieben nachweislich stehen, alle
vier Arbeitsverzeichnisse deckungsgleich mit `seed/`) → vollständiger
`teardown.sh -y` (Board weg, acht Profile weg, acht Wrapper aus
`~/.local/bin` weg, `~/.hermes/kanban/boards/` leer) → `setup.sh` von Null
(Board und acht Profile wieder da, alle mit `ON DISK = yes`).

### Der Weg von Hand, Schritt für Schritt

**1. Board entfernen** (nimmt Tasks, Runs, Events, Logs und Scratch-Workspaces
mit):

```bash
# Falls das Tutorial-Board gerade aktiv ist, erst zurückschalten:
hermes kanban boards show                    # zeigt "Current board: …"
hermes kanban boards switch default

# Archivieren (wiederherstellbar, landet in boards/_archived/):
hermes kanban boards rm kanban-tutorial

# ODER endgültig löschen:
hermes kanban boards rm kanban-tutorial --delete
```

Kontrolle:

```bash
hermes kanban boards list
ls ~/.hermes/kanban/boards/                  # darf kanban-tutorial nicht mehr zeigen
```

**2. Die acht Profile entfernen.** `hermes profile delete` nimmt das
Profilverzeichnis **und** das Wrapper-Skript in `~/.local/bin` mit:

```bash
for p in backend-dev qa-dev translator transcriber copywriter pm reviewer deploy-bot; do
    hermes profile delete "$p" -y
done
```

Kontrolle:

```bash
hermes profile list                # nur noch deine eigenen Profile
ls ~/.hermes/profiles/             # dito
ls ~/.local/bin/ | grep -E 'backend-dev|qa-dev|translator|transcriber|copywriter|^pm$|reviewer|deploy-bot'
```

Der letzte Befehl darf nichts ausgeben.

**3. Von Workern erzeugte Dateien entfernen.** Jede Story hat zwei
Verzeichnisse: `seed/` mit den unveränderlichen Startdateien und `workspace/`
als Arbeitskopie. Zurücksetzen heißt: `workspace/` wegwerfen und aus `seed/`
neu aufbauen.

```bash
cd "Story 0 - Setup"
./reset-workspaces.sh --diff                       # erst ansehen
./reset-workspaces.sh                              # alle zurücksetzen
./reset-workspaces.sh "Story 2 - Fleet Farming"    # nur eine
```

`--diff` ist auch ohne Aufräum-Absicht nützlich — es ist die kompakteste
Antwort auf „was haben die Worker eigentlich angefasst?":

```console
=== Story 1 - Solo Dev ===
  Only in …/workspace: .pytest_cache
  Files …/seed/auth/__init__.py and …/workspace/auth/__init__.py differ
  Only in …/workspace/auth: api.py
  Only in …/workspace/migrations: 001_users.sql
  Only in …/workspace/migrations: 002_sessions.sql
  Only in …/workspace/tests: test_auth.py
```

Der Grund für diesen Umweg über `seed/`: Worker **überschreiben** Startdateien.
In Story 1 schreibt der API-Worker `auth/__init__.py` neu, in Story 3 setzt der
Engineer-Worker `REVIEW-FEEDBACK.md` auf ERLEDIGT. Ein reines „lösche alles
Neue" würde die Story unwiederholbar machen. Verifiziert: nach dem Zurücksetzen
stand in `auth/__init__.py` wieder der leere Stub und in `REVIEW-FEEDBACK.md`
wieder „Status: **OFFEN**".

**4. Nichts weiter.** Das Tutorial hat deine Root-Konfiguration
(`~/.hermes/config.yaml`) **nicht** verändert, keine Skills installiert und
keine Gateway-Einstellungen angefasst. Falls du `hermes dashboard` gestartet
hast:

```bash
hermes dashboard --stop
```

### Was übrig bleiben darf

Die Verzeichnisse `Story 1 - Solo Dev/` … `Story 4 - Circuit Breaker/` in
diesem Repository sind Tutorialmaterial, keine Hermes-Artefakte — die kannst du
behalten oder löschen, wie du magst.

---

## Befehlsreferenz

Was ich in diesem Tutorial benutzt und verifiziert habe. Alles akzeptiert
`--board <slug>` **vor** dem Unterbefehl.

### Board

| Befehl | Zweck |
|---|---|
| `hermes kanban init` | `kanban.db` anlegen. Optional — jeder erste Aufruf tut das selbst. |
| `hermes kanban boards list` | Alle Boards mit Zählwerten |
| `hermes kanban boards create <slug> --name … --icon …` | Board anlegen |
| `hermes kanban boards switch <slug>` | Aktives Board setzen (spart das `--board`) |
| `hermes kanban boards show` | Aktives Board mit DB-Pfad und Zählwerten |
| `hermes kanban boards rm <slug> [--delete]` | Archivieren bzw. endgültig löschen |

### Tasks anlegen und ändern

| Befehl | Zweck |
|---|---|
| `hermes kanban create "<titel>" …` | Task anlegen |
| `… --assignee <profil>` | Zuweisen (Profilname, nicht Person) |
| `… --parent <id>` | Abhängigkeit; wiederholbar |
| `… --workspace dir:<absoluter-pfad>` | Echtes Arbeitsverzeichnis |
| `… --workspace scratch` | Wegwerf-Verzeichnis (Standard) |
| `… --workspace worktree[:<pfad>] --branch <name>` | Echter Git-Worktree |
| `… --tenant <name>` | Mandantenraum, praktisch als Filter |
| `… --priority <n>` | Reihenfolge bei Gleichstand |
| `… --triage` | In der Triage-Spalte parken |
| `… --skill <name>` | Skill in den Worker erzwingen; wiederholbar |
| `… --max-retries <n>` | Circuit Breaker für diesen Task |
| `… --max-runtime 30m` | Laufzeitdeckel; danach SIGTERM/SIGKILL und erneut in die Queue |
| `… --model <m> --provider <p>` | Modell nur für diesen Task |
| `… --idempotency-key <k>` | Doppelanlage verhindern |
| `… --json` | Maschinenlesbar (für `jq -r .id`) |
| `hermes kanban edit <id>` | Felder eines fertigen Tasks korrigieren |
| `hermes kanban assign <id> <profil>` | Zuweisung ändern |
| `hermes kanban link/unlink <eltern> <kind>` | Abhängigkeit nachträglich setzen/lösen |

### Zustand ändern

| Befehl | Zweck |
|---|---|
| `hermes kanban promote <id…>` | `todo`/`blocked` → `ready` (Notweg) |
| `hermes kanban block <id…> --reason …` | Warten auf einen Menschen |
| `hermes kanban schedule <id…> --reason …` | Warten auf Zeit |
| `hermes kanban unblock <id…>` | Zurück nach `ready` bzw. `todo` |
| `hermes kanban complete <id…> --summary … --metadata '{…}'` | Von Hand abschließen |
| `hermes kanban archive <id…>` | Aus der Ansicht nehmen |
| `hermes kanban reclaim <id>` | Claim eines laufenden Workers freigeben |
| `hermes kanban reassign <id> <profil>` | Umhängen, optional mit Reclaim |

⚠ **Sammelabschluss mit Handoff ist absichtlich gesperrt.**
`hermes kanban complete a b c --summary X` wird abgewiesen: dieselbe
Zusammenfassung auf drei Tasks zu kopieren ist fast immer falsch, weil Summary
und Metadata pro Run gelten. Ohne die Handoff-Flags funktioniert der
Sammelabschluss weiter. Das Worker-Werkzeug `kanban_complete` kennt aus dem
gleichen Grund gar keine Sammelvariante.

### Ansehen und diagnostizieren

| Befehl | Zweck |
|---|---|
| `hermes kanban list [--status … --assignee … --tenant … --json]` | Board auflisten |
| `hermes kanban show <id> [--json]` | Task mit Kommentaren, Events und Runs |
| `hermes kanban runs <id>` | Nur die Attempt-Historie |
| `hermes kanban context <id>` | **Was der Worker sieht** — inkl. Eltern-Handoff |
| `hermes kanban log <id> [--tail N]` | Worker-Log, auch live |
| `hermes kanban tail <id>` | Event-Stream eines Tasks verfolgen |
| `hermes kanban watch [--kinds completed,gave_up,timed_out]` | Event-Stream des ganzen Boards |
| `hermes kanban stats` | Zählwerte je Status und Assignee |
| `hermes kanban diagnostics` | Aktive Probleme, mit Handlungsvorschlag |
| `hermes kanban assignees` | Bekannte Profile + `ON DISK` |

### Dispatcher

| Befehl | Zweck |
|---|---|
| `hermes gateway start` | Normalbetrieb, Dispatcher inklusive, alle Boards |
| `hermes kanban dispatch` | Genau ein Tick |
| `hermes kanban dispatch --dry-run` | Zeigen, was ein Tick täte |
| `hermes kanban dispatch --max N` | Spawns pro Tick begrenzen |
| `hermes kanban daemon` | ⚠ **deprecated** in 0.20.0 — der Dispatcher lebt im Gateway |

### Triage-Automatik

| Befehl | Zweck |
|---|---|
| `hermes kanban specify <id>` | Rohe Idee zu einer Spezifikation ausformulieren, dann nach `todo` |
| `hermes kanban decompose <id>` | In einen Graphen von Kind-Tasks zerlegen und auf Spezialisten routen |

Beide benutzen Hilfsmodelle aus `config.yaml`
(`auxiliary.triage_specifier` bzw. `auxiliary.kanban_decomposer`). Die
Automatik steuert `kanban.auto_decompose` (bei dir: `true`) und
`kanban.auto_decompose_per_tick`.

### Werkzeuge, die nur der Worker hat

`kanban_show`, `kanban_list`, `kanban_complete`, `kanban_block`,
`kanban_heartbeat`, `kanban_comment`, `kanban_attach`, `kanban_attach_url`,
`kanban_attachments`, `kanban_create`, `kanban_link`, `kanban_unblock`.

Der Lebenszyklus (`kanban_show` → arbeiten → `kanban_heartbeat` →
`kanban_complete`/`kanban_block`) wird automatisch in den Systemprompt jedes
Workers injiziert. Du musst dafür nichts konfigurieren.

### Die relevanten Konfigurationsschlüssel

```bash
hermes config get kanban.dispatch_interval_seconds    # 60
hermes config get kanban.failure_limit                # 2
hermes config get kanban.auto_decompose               # true
hermes config get kanban.orchestrator_profile         # '' → aktives Default-Profil
hermes config get kanban.default_assignee             # ''
hermes config get kanban.dispatch_in_gateway          # true
hermes config get kanban.dispatch_stale_timeout_seconds  # 14400
```

Setzen mit `hermes config set <schlüssel> <wert>`.
