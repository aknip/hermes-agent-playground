# Verifikationsprotokoll

Was für dieses Tutorial **real ausgeführt** wurde, was dabei herauskam, und was
ich **nicht** verifizieren konnte. Diese Liste ist Teil des Ergebnisses, nicht
ein Eingeständnis: sie sagt dir, welchen Aussagen du ohne Nachprüfen trauen
kannst.

## Testumgebung

| | |
|---|---|
| Hermes Agent | v0.20.0 (2026.8.3), Installationsmethode `git` |
| Installationsort | `/Users/<user>/.hermes/hermes-agent` |
| Python | 3.11.15, OpenAI SDK 2.24.0 |
| Betriebssystem | macOS, Darwin 25.5.0 |
| Modell der Worker | `deepseek/deepseek-v4-flash-0731` über OpenRouter (aus der Root-Konfiguration übernommen) |
| Board | `kanban-tutorial` (eigens angelegt, `~/.hermes/kanban/boards/kanban-tutorial/kanban.db`) |
| Datum der Durchführung | 2026-08-10 |
| `jq` | 1.x, `/usr/bin/jq` |

Als Doku-Quelle diente **nicht** die Website, sondern die Markdown-Quelle im
lokalen Git-Checkout — sie passt exakt zur installierten Version:
`~/.hermes/hermes-agent/website/docs/user-guide/features/kanban-tutorial.md`
und `…/kanban.md`.

## Zusammenfassung

| Bereich | Status |
|---|---|
| Setup: Board, 8 Profile, `config.yaml`-Falle | ✅ real ausgeführt, mehrfach von Null |
| Teardown + `reset-workspaces.sh` | ✅ real ausgeführt, danach `setup.sh` von Null wiederholt |
| Story 1: Dependency-Kette, Handoff, echte Worker | ✅ komplett, 3 Runs, alle `completed` |
| Story 2: 12 Tasks parallel auf 3 Profile | ✅ komplett, 12 Runs, alle `completed` |
| Story 3: Block, `unblock`, zweiter Run, Reviewer | ✅ komplett, 4 Runs (1× `blocked`, 3× `completed`), Reviewer-Urteil APPROVED |
| Story 4a: Circuit Breaker → `gave_up` | ✅ real ausgelöst, mit anderem Auslöser als in der Doku |
| Story 4a: Respawn-Sperre (undokumentiert) | ✅ real ausgelöst |
| Story 4b: Crash Recovery via `kill -9` | ✅ real ausgelöst, Run 1 `crashed`, Run 2 `completed` |
| Web-Dashboard startet und antwortet | ✅ HTTP 200 auf `127.0.0.1:9119` |
| Desktop-App-Oberfläche | ⚠️ nur aus dem Quellcode belegt, nicht klickend geprüft |
| Gateway-Notifications (Telegram/Slack/Discord) | ❌ nicht getestet |
| `worktree`-Workspaces | ❌ nicht getestet |
| `specify` / `decompose` | ❌ nicht getestet |
| Screenshots der offiziellen Doku | ❌ nicht nachgestellt |

## Fehler in der offiziellen Doku, die ich belegen kann

### 1. Die acht Profile werden vorausgesetzt, aber nie angelegt

Das Tutorial benutzt ab Story 1 `backend-dev`, `qa-dev`, `translator`,
`transcriber`, `copywriter`, `pm`, `reviewer`, `deploy-bot`. Auf einer
Standard-Installation existiert keines davon.

### 2. `hermes profile create` allein macht ein Profil nicht dispatchbar

**Nachgewiesen.** Ein Profil zählt für Kanban nur als vorhandener Assignee, wenn
`~/.hermes/profiles/<name>/config.yaml` existiert
(`kanban_db.list_profiles_on_disk`). `hermes profile create` legt diese Datei
nicht an. Folge: `hermes profile list` zeigt das Profil, `hermes kanban
assignees` nicht — und Tasks bleiben ohne Fehlermeldung auf `ready` liegen.

Beleg (gekürzte Konsolenausgabe):

```console
$ hermes profile create backend-dev --no-skills --description "…"
Profile 'backend-dev' created at …/.hermes/profiles/backend-dev

$ ls …/.hermes/profiles/backend-dev/
.env  .no-bundled-skills  SOUL.md  profile.yaml  cron/ home/ logs/ …
                                  ← keine config.yaml

$ hermes kanban --board kanban-tutorial assignees
NAME         ON DISK   COUNTS
default      yes       (idle)
developer    yes       (idle)
summarizer   yes       (idle)        ← backend-dev fehlt

$ hermes -p backend-dev config set model.default "deepseek/deepseek-v4-flash-0731"
✓ Set model.default = … in …/.hermes/profiles/backend-dev/config.yaml

$ hermes kanban --board kanban-tutorial assignees
NAME          ON DISK   COUNTS
backend-dev   yes       (idle)       ← jetzt da
```

Zusatzbefund: `--no-skills` und `--clone/--clone-from/--clone-all` schließen
sich gegenseitig aus. Ein schlankes Profil mit funktionierender `config.yaml`
geht also nur über den Weg „create, dann `config set`".

### 3. Das Board hat 8 Spalten, nicht 6

**Nachgewiesen aus dem Quellcode beider Oberflächen.**

`hermes_cli/kanban_db.py`:

```python
VALID_STATUSES = {"triage", "todo", "scheduled", "ready", "running",
                  "blocked", "review", "done", "archived"}
```

`plugins/kanban/dashboard/plugin_api.py`:

```python
BOARD_COLUMNS: list[str] = [
    "triage", "todo", "scheduled", "ready", "running", "blocked", "review", "done",
]
```

Der Kommentar direkt darüber im Quellcode weist ausdrücklich darauf hin, dass
`scheduled` eine erstklassige Wartespalte ist. `hermes kanban stats` bestätigt
das zur Laufzeit — es zählt `scheduled` mit. Die CLI hat entsprechend einen
`schedule`-Unterbefehl, den die Doku nicht erwähnt.

### 4. Das AWS-Beispiel für den Circuit Breaker funktioniert nicht

Die Doku schreibt, ein fehlendes `AWS_ACCESS_KEY_ID` lasse den Spawn mit
`RuntimeError: AWS_ACCESS_KEY_ID not set` scheitern. Das ist in 0.20.0 nicht so:
eine fehlende Umgebungsvariable verhindert den Spawn nicht.

`spawn_failed` entsteht im Dispatcher an genau zwei Stellen
(`kanban_db.py`, Dispatch-Schleife): wenn die Workspace-Auflösung eine Exception
wirft, oder wenn der Prozess-Spawn selbst eine wirft. Beides habe ich benutzt,
um den Breaker echt auszulösen — siehe unten.

### 5. Nicht dokumentiert: die Respawn-Sperre

**Neu gefunden.** Vor jedem Spawn läuft `check_respawn_guard`. Passt der letzte
Fehlertext auf dieses Muster, versucht der Dispatcher es **gar nicht** erneut:

```python
_RESPAWN_BLOCKER_RE = re.compile(
    r"\b(quota|rate[\s_\-]?limit|429|403|auth\w*|"
    r"unauthorized|forbidden|billing|subscription|"
    r"access[\s_]denied|permission[\s_]denied|"
    r"invalid[\s_]api[\s_]key)\b", re.IGNORECASE)
```

Der Task bleibt dann auf `ready`, der Dispatcher meldet `respawn_guarded`, und
der Circuit Breaker wird nie erreicht. **`hermes kanban diagnostics` zeigt
diesen Fall nicht an** — nur das Event-Log verrät ihn. Das ist praktisch
relevant: so ein Task sieht auf dem Board aus wie „wartet auf den Dispatcher",
wird aber nie wieder angefasst.

Weitere Sperrgründe im selben Wächter: ein `completed`-Run innerhalb der letzten
Stunde (`_RESPAWN_GUARD_SUCCESS_WINDOW = 3600`), eine GitHub-PR-URL in einem
Kommentar innerhalb von 24 Stunden (`_RESPAWN_GUARD_PR_WINDOW = 86400`) und ein
Rate-Limit-Cooldown von 300 Sekunden.

### 6. Nicht dokumentiert: `## Recent work by @<profil>` im Worker-Kontext

`hermes kanban context` liefert neben `## Prior attempts on this task` und
`## Parent task results` einen dritten Abschnitt: die letzten Arbeitsergebnisse
desselben Profils, auch aus fremden Task-Ketten.

### 7. `hermes kanban daemon` ist deprecated

Die Hilfe sagt es klar: „DEPRECATED — dispatcher now runs in the gateway. Use
`hermes gateway start`." Das Tutorial erwähnt den Daemon nicht mehr, andere
Doku-Stellen aber schon.

### 8. Ein laufendes Gateway greift auf *jedes* Board zu

**Zweimal beobachtet.** Die Doku erwähnt `hermes gateway start` als Weg, den
Dispatcher zu betreiben, sagt aber nicht, dass das Gateway **alle** Boards
bedient — auch eines, das erst Sekunden vorher entstanden ist und auf das
niemand es hingewiesen hat.

Erster Fall: unmittelbar nach `create-tasks.sh` von Story 2 stand ein Task
bereits auf `running`, bevor ich einen Dispatch angestoßen hatte. Zweiter Fall:
gegen Ende des Durchlaufs habe ich Kontrollaufgaben angelegt und nur
`dispatch --dry-run` ausgeführt — das Gateway hat sie trotzdem echt
ausgeführt und Dateien ins Arbeitsverzeichnis geschrieben.

Praktische Folge: solange ein Gateway läuft, kann man einen Task nicht „erst
anlegen und später ansehen". Wer das braucht, legt ihn mit `--triage` oder
`block` geparkt an — oder hält das Gateway mit `hermes gateway stop` an.

### 9. Desktop-App ≠ Web-Dashboard

Die Doku sagt „`hermes dashboard`, dann links auf Kanban" und zeigt Screenshots
dieser Web-Oberfläche. Die Desktop-App hat ein **eigenes** Kanban-Board
(`apps/desktop/src/plugins/kanban/`), das

- **standardmäßig ausgeschaltet** ist (`defaultEnabled: false` in `plugin.tsx`,
  Kommentar: „Ships OFF by default … registers nothing until the user flips the
  switch") — einzuschalten unter Settings ▸ Plugins,
- **keinen** „Nudge dispatcher"-Knopf hat (laut Quellkommentar in `board.tsx`
  reiten Dispatch-Anstöße auf jeder Schreiboperation mit),
- **kein** „✨ Specify" pro Karte hat (der String existiert nur im
  Web-Dashboard-Bundle),
- „Decompose" nur als Auto-Schalter in den Orchestrierungs-Einstellungen hat,
  nicht pro Karte.

Belegt durch Zeichenkettenvergleich: `Nudge dispatcher`, `Decompose`, `Specify`
und `Lanes by profile` finden sich alle in
`plugins/kanban/dashboard/dist/index.js`; im Desktop-Plugin fehlen `Specify`
und der Nudge-Knopf.

## Messwerte der Durchläufe

### Setup

`setup.sh` von Null: Board angelegt, 8 Profile angelegt, 32 `config set`-Aufrufe
(4 Schlüssel × 8 Profile), Verifikation grün — alle acht mit `ON DISK = yes`.

### Rückbau — drei Stufen, alle geprüft

Nach dem Durchlauf aller vier Stories, in dieser Reihenfolge:

1. **`./teardown.sh --files-only -y`** — Board `kanban-tutorial` blieb stehen
   (`archived=4, done=19`), alle acht Profile blieben mit ihrem Modell in
   `hermes profile list`, alle vier Arbeitsverzeichnisse deckungsgleich mit
   `seed/` (leere `diff -rq`-Ausgabe). Inhaltlich geprüft: Story 1s
   `auth/__init__.py` war wieder der leere Stub, Story 3s `REVIEW-FEEDBACK.md`
   wieder auf „Status: **OFFEN**". Beide Dateien hatten Worker überschrieben —
   das ist der Grund für die `seed/`-Mechanik.
2. **`./teardown.sh -y`** — Board gelöscht, 8 Profile gelöscht, 8 Wrapper aus
   `~/.local/bin` entfernt, `~/.hermes/kanban/boards/` leer. Kontrollausgabe
   zeigte nur noch die vorbestehenden Profile `default`, `developer`,
   `summarizer`, `test-me`.
3. **`./setup.sh`** — Board und alle acht Profile neu angelegt, Verifikation
   grün (alle `ON DISK = yes`).

Der Datei-Rücksetzpfad wurde also gegen echte Worker-Ausgabe getestet, nicht
gegen ein leeres Verzeichnis: 12 Dateien aus Story 2, `api.py` /
`test_auth.py` / `__pycache__` / `.pytest_cache` aus Story 1,
`spec/password-reset.md` und `REVIEW-VERDICT.md` aus Story 3, 11 Reports aus
Story 4.

### `pump.sh`

Alle drei Aufrufarten einzeln geprüft, unverfälscht (nicht in eine Pipe):

| Aufruf | Ergebnis |
|---|---|
| `./pump.sh 15 20` mit einer offenen Aufgabe | `[01] running=1` → `[02] done=1` → „Nichts mehr offen", Exit 0 |
| `./pump.sh --once` | ein Dispatch-Bericht, Exit 0 |
| `./pump.sh 5 3` auf leerem Board | erkennt sofort, dass nichts offen ist, Exit 0 |

Nachträglich korrigiert: `--once` wurde vor der Zuweisung von `INTERVAL`
abgefangen, damit die Option nicht als Intervall gelesen wird.

### Endzustand nach der Abgabe

Board neu aufgebaut statt aufgeräumt, damit auch keine archivierten Testreste
bleiben: `teardown.sh --keep-profiles -y` → `setup.sh`. Kontrolle:
`hermes kanban list --archived` leer, `stats` überall 0, alle acht Profile
`ON DISK = yes`, `reset-workspaces.sh --diff` ohne Abweichung.

### Rauchtest vor Story 1

Ein Wegwerf-Task an `backend-dev` mit `--workspace dir:/tmp/kanban-smoke`:

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  completed     backend-dev            21s  2026-08-10 08:16
     → Created /tmp/kanban-smoke/HELLO.md containing the line "hello from backend-dev"
```

Wichtig daran: die Profil-`.env` war **leer**. Der Worker hat die API-Zugänge
aus der Umgebung geerbt. Ein API-Key pro Profil ist also nicht nötig.

### Story 1 — Solo Dev

Drei Tasks, Kette `SCHEMA → API → TESTS`, gesamte Kette rund 4 Minuten.

Ausgangszustand exakt wie dokumentiert — nur der elternlose Task auf `ready`:

```console
▶ t_f92e2974  ready     backend-dev          [auth-project]  Design auth schema
◻ t_94cb365d  todo      backend-dev          [auth-project]  Implement auth API endpoints
◻ t_7793e530  todo      qa-dev               [auth-project]  Write auth integration tests
```

Alle drei Runs `completed` (65 s / ~1 min / ~1 min). Erzeugte Dateien:
`migrations/001_users.sql`, `migrations/002_sessions.sql`, `auth/api.py`,
`auth/__init__.py` (überschrieben), `tests/test_auth.py` mit 14 Tests.

Der Handoff war nachweislich wirksam: `hermes kanban context $API` zeigte vor
dem Abschluss des Elternteils keinen Eltern-Abschnitt, danach den vollen
Summary plus `metadata` mit `changed_files` und sieben Design-Entscheidungen.

### Story 2 — Fleet Farming

Zwölf Tasks, drei Profile. **Alle zwölf um 08:34 gestartet** — also im selben
Dispatch-Fenster, echte Parallelität, kein Fehlversuch:

```console
  1  completed     translator             48s
  1  completed     translator             59s
  1  completed     translator             57s
  1  completed     transcriber             4m
  1  completed     transcriber             1m
  1  completed     transcriber             1m
  1  completed     transcriber             1m
  1  completed     transcriber             3m
  1  completed     copywriter              1m   (×4)
```

Zwölf erzeugte Dateien. Stichproben geprüft: die deutsche Übersetzung erhält
die Markdown-Struktur und überträgt den Ton, der Produkttext für SKU-1002
benutzt ausschließlich Zahlen aus der CSV (18/8 Edelstahl, matte sand, 410 g,
24 h/12 h, 34,90 EUR).

Bemerkenswert: kaum war das neue Board erzeugt, hat der **Gateway-Dispatcher**
von selbst den ersten Task übernommen. Der Gateway bedient also auch neu
angelegte Boards, ohne Zutun.

### Story 3 — Rollen-Pipeline mit Retry

`SPEC` (pm) → `IMPL` (backend-dev) → `REVIEW` (reviewer).

`SPEC` lief in gut einer Minute durch und legte fünf Akzeptanzkriterien als
Liste unter `metadata.acceptance` ab. `IMPL` wurde daraufhin automatisch von
`todo` auf `ready` befördert (Event `promoted`).

`IMPL`, erster Versuch: 812 Sekunden (13 Minuten), 13 Heartbeats, Outcome
**`blocked`** mit `kind: 'needs_input'`. Der Block-Grund war der Inhalt von
`REVIEW-FEEDBACK.md`, wie im Task-Body verlangt.

Nach `hermes kanban unblock` zeigte `hermes kanban context $IMPL` genau das,
was die Doku verspricht:

```console
## Prior attempts on this task
### Attempt 1 — blocked (backend-dev, 2026-08-10 08:28, 14m ago)
Review-Feedback … (1) Passwortstärke wird nicht geprüft … (2) Der Reset-Link
ist nicht single-use …

## Parent task results
### t_401a67c8 (completed 15m ago)
Spezifikation für den Passwort-Reset … geschrieben …
_metadata_: {"acceptance": ["AC-1: …", "AC-2: …", "AC-3: …", "AC-4: …", "AC-5: …"], …}
```

Nebenbefund zur Numerierung: `hermes kanban runs` numeriert die Versuche eines
Tasks fortlaufend ab 1, `hermes kanban show` zeigt dagegen die
board-globale `run_id` (im Test „Runs (1): #5"). Wer beide Ausgaben vergleicht,
darf sich davon nicht irritieren lassen.

Zweiter Versuch nach `unblock`, real gemessen:

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  blocked       backend-dev            13m  2026-08-10 08:28
  2  completed     backend-dev             4m  2026-08-10 08:43
     → Zweiter Versuch: Die beiden blockierenden Review-Punkte in auth/reset.py
       behoben und per Test gegen eine echte sqlite3-In-Memory-DB verifiziert
       (18/18 Checks, alle 5 Akzeptanzkriterien) …
```

**13 Minuten gegen 4 Minuten** — der zweite Worker hat nicht von vorne
angefangen. Das ist der Messwert zur Doku-Behauptung „addresses those specific
findings instead of re-running from scratch".

`metadata` von Run 2:

```json
{"changed_files": ["auth/reset.py", "REVIEW-FEEDBACK.md"], "review_iteration": 2,
 "acceptance_verified": ["AC-1","AC-2","AC-3","AC-4","AC-5"],
 "password_strength_checks": ["laenge","komplexitaet","trivialpasswoerter","email_aehnlichkeit"],
 "single_use_token": true, "sessions_invalidated_on_reset": true}
```

Der Reviewer wurde anschließend automatisch nach `ready` befördert, lief eine
Minute und schloss mit `completed` ab:

```console
  1  completed     reviewer                1m  2026-08-10 08:47
     → Passwort-Reset-PR für APPROVED befunden. Alle 5 Akzeptanzkriterien aus
       spec/password-reset.md und beide Review-Punkte erfüllt.
```

Er schrieb `REVIEW-VERDICT.md` mit einem Nachweis pro Akzeptanzkriterium.
Endzustand: alle drei Tasks auf `done`, `$IMPL` mit zwei Runs.

### Story 4b — Crash Recovery

Task: `data/events.csv` (420 Zeilen) in zehn Kategorie-Reports zerlegen,
`--max-retries 3`. 30 Sekunden nach dem Spawn `kill -9` auf die PID aus dem
Event-Log.

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  crashed       backend-dev            32s  2026-08-10 08:43
     ✖ pid 98251 not alive
  2  completed     backend-dev             1m  2026-08-10 08:44
     → data/events.csv (420 Zeilen) in 10 Kategorie-Reports zerlegt und
       reports/SUMMARY.md erstellt.

Events: [run 28] claimed → spawned → heartbeat → crashed
        [run 29] claimed → spawned → heartbeat → heartbeat → completed
```

Elf Dateien in `reports/` erzeugt (zehn Kategorien plus `SUMMARY.md`). Der
abgestürzte Run bleibt mit `pid 98251 not alive` im `error`-Feld erhalten.

Einschränkung: der Crash wurde per `kill -9` erzeugt, nicht durch einen echten
OOM. Der Erkennungspfad im Dispatcher (`kill(pid, 0)` → tote PID) ist derselbe.

### Story 4a — Circuit Breaker

Auslöser: `--workspace dir:/dev/null/staging`. `/dev/null` ist eine
Gerätedatei; `mkdir -p` darunter wirft `NotADirectoryError` (Errno 20). Dieser
Fehlertext enthält kein Auth-/Quota-Muster, die Respawn-Sperre greift also
nicht.

Mit `--max-retries 3`, real gemessen:

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  spawn_failed  deploy-bot              0s  2026-08-10 08:39
     ✖ workspace: [Errno 20] Not a directory: '/dev/null/staging'
  2  spawn_failed  deploy-bot              0s  2026-08-10 08:39
     ✖ workspace: [Errno 20] Not a directory: '/dev/null/staging'
  3  gave_up       deploy-bot              0s  2026-08-10 08:39
     ✖ workspace: [Errno 20] Not a directory: '/dev/null/staging'
```

Event-Log — **identisch zur Sequenz in der offiziellen Doku**:

```
created → claimed → spawn_failed → claimed → spawn_failed → claimed → gave_up
```

Task-Status danach `blocked`. `hermes kanban diagnostics` meldete den Fall
sauber, inklusive Handlungsvorschlag:

```console
1 active diagnostic(s) across 1 task(s):

  t_009b64eb  blocked   @deploy-bot   Deploy to staging …
    !! [error] repeated_failures: Agent spawn x3: workspace: [Errno 20] Not a directory: '/dev/null/staging'
       data: consecutive_failures=3 | most_recent_outcome=spawn_failed | failure_threshold=2 | failure_limit=2
       → Verify profile: hermes -p deploy-bot doctor
```

`hermes kanban unblock` brachte ihn zurück auf `ready` — verifiziert.

### Story 4a — Respawn-Sperre

Auslöser: `--workspace dir:/Volumes/deploy-share/staging` auf ein nicht
gemountetes Volume. `mkdir` liefert `PermissionError` (Errno 13); der Text
enthält „Permission denied" und passt damit auf `_RESPAWN_BLOCKER_RE`.

```console
#    OUTCOME       PROFILE            ELAPSED  STARTED
  1  spawn_failed  deploy-bot              0s  2026-08-10 08:39
     ✖ workspace: [Errno 13] Permission denied: '/Volumes/deploy-share'

Events: created → claimed → spawn_failed → respawn_guarded → respawn_guarded
```

Drei Dispatch-Ticks, kein zweiter Versuch, kein `gave_up`, Status blieb `ready`.
`hermes kanban diagnostics` zeigte diesen Task **nicht** an.

Beide Teile von Story 4a kosten **keine Tokens**: der Fehler tritt auf, bevor
das Modell gestartet wird.

## Was ich nicht verifiziert habe

- **Die Desktop-App klickend.** Alle Aussagen über ihre Oberfläche stammen aus
  dem Quellcode des Plugins (`apps/desktop/src/plugins/kanban/`), aus der
  i18n-Schlüsselliste und aus Zeichenkettenvergleichen gegen das
  Web-Dashboard-Bundle. Der Punkt „Kanban ist standardmäßig aus" ist durch
  `defaultEnabled: false` im Quellcode belegt, nicht durch einen Blick in dein
  Settings-Fenster.
- **Die Web-Oberfläche klickend.** Verifiziert ist nur: `hermes dashboard`
  startet, hört auf `127.0.0.1:9119` und liefert HTTP 200. Die API-Endpunkte
  verlangen eine Browser-Sitzung, deshalb habe ich sie nicht per `curl`
  geprüft. Die Existenz der beschriebenen Knöpfe ist aus dem ausgelieferten
  Bundle belegt.
- **Gateway-Notifications** nach Telegram, Slack oder Discord
  (`notify-subscribe`). Nicht konfiguriert, nicht getestet.
- **`worktree`-Workspaces.** Alle Stories benutzen `dir:` oder `scratch`.
- **`hermes kanban specify` und `decompose`.** Beide rufen Hilfsmodelle
  (`auxiliary.triage_specifier`, `auxiliary.kanban_decomposer`); die
  Beschreibungen im Tutorial stammen aus Hilfetexten und Quellcode.
- **Der Review-Status als Ablauf.** Dass die Spalte existiert und wie sie
  gefüllt wird, ist aus dem Quellcode belegt; einen echten SDLC-Review-Lauf mit
  PR habe ich nicht gefahren.
- **Andere Betriebssysteme.** Nur macOS. Insbesondere die beiden
  Story-4-Auslöser sind pfadabhängig: `/dev/null/…` funktioniert auf jedem
  Unix, `/Volumes/…` ist macOS-spezifisch. Unter Linux wäre das Gegenstück ein
  nicht schreibbares Verzeichnis wie `/proc/kanban`.
- **Andere Modelle.** Alle Worker liefen auf
  `deepseek/deepseek-v4-flash-0731`. Laufzeiten und Textqualität sind
  modellabhängig; die Kanban-Mechanik ist es nicht.
