
Hier sind Informationen und Dokumentation zum Hermes Agent Kanban Board

https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban
https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban-tutorial
https://github.com/NousResearch/hermes-agent/blob/main/docs/hermes-kanban-v1-spec.pdf

Ich setze Hermes Agent 0.20.0 (0.17.0), Desktop Version für Mac, ein.

Aufgabe:
Ich möchte das Tutorial (https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban-tutorial) Schritt für Schritt durchgehen. Mir ist nicht klar, was ich genau machen muss (was gebe ich im Terminal ein, was kann ich über die Hermes Agent Desktop App umsetzen). Ausserdem habe ich den Eindruck, dass ich bestimmte Vorasussetzungen schaffen muss (Hermes Agent Profile, Arbeitsdateien etc.), damit ich die einzelnen Tutorials durchführen kann.
Bitte erstelle ein ausführliches, Schritt für Schritt Tutorial, das auch alle benötigten Artefakte (Agents, Profile, Skills, Arbeitsdateien etc.) enthält. Überprüfe dabei durch Tests, ob alle Funktionen und Befehle in meiner Hermes Agent Version funktionieren (ggf. beziehen sich die Tutorials auf ältere Versionen und/oder andere Betriebssysteme).
Ergebnis:
- Tutorialdokumentation (.md)
- Verzeichnis mit benötigten Artefakten pro Tutorial ("/Story 1", "/Story 2" etc.)




In diesem Repo ist ein Schritt für Schritt Tutorial zum Hermes Agent Kanban Board, basierend auf https://hermes-agent.nousresearch.com/docs/user-guide/features/kanban-tutorial

Ich setze Hermes Agent 0.20.0 (0.17.0), Desktop Version für Mac, ein.

Aufgabe:
Ich möchte ergänzend nur auch die Usecases aus https://github.com/NousResearch/hermes-agent/blob/main/docs/hermes-kanban-v1-spec.pdf (Kapitel 8 und 9) in das Tutorial übernehmen (als Story 5 folgende)

Gehe analog zu den bestehenden Tutorial-Kapiteln/-Stories vor, erstelle für die neuen Stories jeweils ein ausführliches, Schritt für Schritt Tutorials, das auch alle benötigten Artefakte (Agents, Profile, Skills, Arbeitsdateien etc.) enthält. Überprüfe dabei durch Tests, ob alle Funktionen und Befehle in meiner Hermes Agent Version funktionieren (die Stories im PDF sind älter bzw. aus der Konzeptionsphase von Hermes Agent, hier rechne ich mit inhaltlichen und funktionalen Anpassungen).

Änderung / Überarbeitung für alle - auch schon bestehenden - Stories: Jede Story soll für sich isoliert als einzelnes Tutorial ausführbar sein und ein individuelles Setup beinhalten (mit den für die jeweilige Story benötigten Profilen etc) - es soll also kein konsolidiertes Setup für alle Stories mehr geben, das Verzeichnis "Story 0 - Setup" entfällt bzw. kann dann gelöscht werden.

Ergebnis:
- Erweiterete Tutorialdokumentation (.md)
- Verzeichnis mit benötigten Artefakten pro Tutorial ("/Story 5", "/Story 6" etc.)
